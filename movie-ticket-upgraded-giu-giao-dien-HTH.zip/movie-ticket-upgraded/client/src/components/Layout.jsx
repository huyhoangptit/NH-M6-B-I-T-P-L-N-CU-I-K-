import { Outlet } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';

export default function Layout() {
  return (
    <div className="app-root theme-dark">
      <Header />
      <main className="page-shell"><Outlet /></main>
      <Footer />
    </div>
  );
}
