import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { api, getApiError } from '../services/api';
import SectionTitle from '../components/SectionTitle';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';

function getBookingStatus(status) {
  const labels = {
    pending_payment: 'Chờ thanh toán',
    payment_reported: 'Đã báo chuyển khoản',
    confirmed: 'Đã xác nhận',
    cancelled: 'Đã hủy',
    expired: 'Hết hạn thanh toán',
    payment_rejected: 'Thanh toán bị từ chối'
  };
  return labels[status] || status;
}

export default function HistoryPage() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const location = useLocation();

  const load = async () => {
    try {
      const response = await api.get('/bookings/my');
      setBookings(response.data.data.bookings);
    } catch (err) {
      setError(getApiError(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const cancel = async (id) => {
    if (!window.confirm('Bạn chắc chắn muốn hủy đơn/vé này?')) return;
    try {
      await api.patch(`/bookings/${id}/cancel`);
      await load();
    } catch (err) {
      setError(getApiError(err));
    }
  };

  return (
    <div className="container section-block">
      <SectionTitle eyebrow="TÀI KHOẢN" title="Lịch sử vé" description="Đơn chờ thanh toán cần được chuyển khoản và Admin xác nhận. QR vé chỉ được cấp sau khi đã xác nhận thanh toán." />
      {location.state?.success && <div className="alert alert-success">{location.state.success}</div>}
      <ErrorMessage message={error} />
      {loading ? <Loading /> : bookings.length ? (
        <div className="ticket-list">
          {bookings.map((booking) => {
            const start = new Date(booking.showtime?.startAt);
            const canCancel = ['pending_payment', 'confirmed'].includes(booking.status)
              && !booking.checkedInAt
              && start.getTime() - Date.now() >= 2 * 60 * 60 * 1000;
            const qrStillValid = booking.showtime?.endAt
              ? new Date(booking.showtime.endAt).getTime() + 24 * 60 * 60 * 1000 > Date.now()
              : false;
            return (
              <article className="ticket-card ticket-card-with-qr" key={booking._id}>
                <div className="ticket-main-info">
                  <span className="eyebrow">MÃ ĐƠN {booking.ticketCode}</span>
                  <h3>{booking.showtime?.movie?.title || 'Phim'}</h3>
                  <p>{start.toLocaleString('vi-VN')} · {booking.showtime?.room?.name}</p>
                  <p>Ghế: {booking.seats.map((seat) => seat.code).join(', ')}</p>
                  {booking.customer?.name && <p>Người đặt: {booking.customer.name}</p>}
                  {booking.voucher?.code && <p>Voucher: <b className="invoice-seats">{booking.voucher.code}</b> · Giảm {Number(booking.discountAmount || 0).toLocaleString('vi-VN')} đ</p>}
                  {booking.payment?.transferContent && <p>Nội dung chuyển khoản: <b>{booking.payment.transferContent}</b></p>}
                  {booking.payment?.reportedAt && <p>Đã báo chuyển khoản lúc {new Date(booking.payment.reportedAt).toLocaleString('vi-VN')}</p>}
                  {booking.checkedInAt && <p className="ticket-checked-in">Đã sử dụng lúc {new Date(booking.checkedInAt).toLocaleString('vi-VN')}</p>}
                  {booking.payment?.rejectionReason && <p className="ticket-payment-error">Lý do: {booking.payment.rejectionReason}</p>}
                </div>
                <div className="ticket-side">
                  <b>{booking.total.toLocaleString('vi-VN')} đ</b>
                  <span className={`status-pill ${booking.status}`}>{getBookingStatus(booking.status)}</span>
                  {booking.status === 'pending_payment' && <Link className="btn btn-primary btn-small" to={`/payment/${booking._id}`}>Tiếp tục thanh toán</Link>}
                  {booking.status === 'payment_reported' && <Link className="btn btn-ghost btn-small" to={`/payment/${booking._id}`}>Xem trạng thái</Link>}
                  {booking.status === 'confirmed' && !booking.checkedInAt && booking.qrToken && qrStillValid && (
                    <details className="ticket-qr-details">
                      <summary>Hiển thị mã QR vé</summary>
                      <div className="ticket-qr-content">
                        <QRCodeSVG value={booking.qrToken} size={164} level="H" includeMargin bgColor="#ffffff" fgColor="#111111" />
                        <b>{booking.ticketCode}</b>
                        <strong>{booking.showtime?.movie?.title || 'Vé xem phim'}</strong>
                        <small>{start.toLocaleString('vi-VN')} · {booking.showtime?.room?.name}</small>
                        <small>Ghế: {booking.seats.map((seat) => seat.code).join(', ')}</small>
                        <small>Đưa mã QR này cho nhân viên rạp để xác thực vé.</small>
                        <button type="button" className="btn btn-ghost btn-small" onClick={() => window.print()}>In vé / Lưu PDF</button>
                      </div>
                    </details>
                  )}
                  {canCancel && <button className="btn btn-danger btn-small" onClick={() => cancel(booking._id)}>Hủy đơn/vé</button>}
                </div>
              </article>
            );
          })}
        </div>
      ) : <div className="empty-state">Bạn chưa có vé nào.</div>}
    </div>
  );
}
