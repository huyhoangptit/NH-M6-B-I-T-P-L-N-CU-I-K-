import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, getApiError } from '../services/api';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';

function formatMoney(value) {
  return `${Number(value || 0).toLocaleString('vi-VN')} VNĐ`;
}

function formatCountdown(expiresAt, tick) {
  void tick;
  if (!expiresAt) return '--:--';
  const remaining = Math.max(0, new Date(expiresAt).getTime() - Date.now());
  const minutes = Math.floor(remaining / 60000);
  const seconds = Math.floor((remaining % 60000) / 1000);
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

export default function PaymentPage() {
  const { bookingId } = useParams();
  const [booking, setBooking] = useState(null);
  const [payment, setPayment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [reporting, setReporting] = useState(false);
  const [tick, setTick] = useState(0);
  const [copyMessage, setCopyMessage] = useState('');

  const load = useCallback(async (showLoading = false) => {
    if (showLoading) setLoading(true);
    try {
      const response = await api.get(`/bookings/${bookingId}/payment`);
      setBooking(response.data.data.booking);
      setPayment(response.data.data.payment);
      setError('');
    } catch (err) {
      setError(getApiError(err));
    } finally {
      if (showLoading) setLoading(false);
    }
  }, [bookingId]);

  useEffect(() => { load(true); }, [load]);

  useEffect(() => {
    const timer = window.setInterval(() => setTick((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Kiểm tra trạng thái thanh toán định kỳ để trang tự cập nhật khi Admin xác nhận tiền.
  useEffect(() => {
    const timer = window.setInterval(() => load(false), 10000);
    return () => window.clearInterval(timer);
  }, [load]);

  const countdown = useMemo(() => formatCountdown(payment?.expiresAt, tick), [payment?.expiresAt, tick]);
  const expiredOnClient = payment?.expiresAt && new Date(payment.expiresAt).getTime() <= Date.now();
  const pending = booking?.status === 'pending_payment';
  const reported = booking?.status === 'payment_reported';
  const confirmed = booking?.status === 'confirmed';
  const statusText = {
    pending_payment: 'Chờ thanh toán',
    payment_reported: 'Đã báo chuyển khoản – chờ đối soát',
    confirmed: 'Đã xác nhận thanh toán',
    cancelled: 'Đã hủy đơn',
    expired: 'Đơn đã hết hạn',
    payment_rejected: 'Thanh toán chưa được xác nhận'
  }[booking?.status] || 'Đang kiểm tra';

  const copyText = async (value, label) => {
    try {
      await navigator.clipboard.writeText(String(value));
      setCopyMessage(`Đã sao chép ${label}.`);
      window.setTimeout(() => setCopyMessage(''), 2200);
    } catch {
      setCopyMessage('Trình duyệt không cho phép sao chép tự động. Bạn hãy bôi đen và sao chép thủ công.');
    }
  };

  const notifyTransferred = async () => {
    setReporting(true);
    try {
      const response = await api.post(`/bookings/${bookingId}/notify-payment`);
      setBooking(response.data.data.booking);
      await load(false);
    } catch (err) {
      setError(getApiError(err));
    } finally {
      setReporting(false);
    }
  };

  if (loading) return <div className="flow-page"><div className="container section-block"><Loading /></div></div>;
  if (!booking) return <div className="flow-page"><div className="container section-block"><ErrorMessage message={error || 'Không tìm thấy đơn thanh toán.'} /><Link className="btn btn-primary" to="/history">Quay lại lịch sử vé</Link></div></div>;

  return (
    <div className="flow-page bank-payment-page">
      <div className="flow-topbar flow-topbar-centered">
        <Link to="/history" className="flow-back" aria-label="Quay lại lịch sử vé">←</Link>
        <h1>Thanh Toán Chuyển Khoản</h1>
      </div>

      <main className="bank-payment-layout">
        <section className="bank-payment-main">
          <div className="bank-payment-heading">
            <span className="bank-payment-kicker">HTH CINEMA · VIETQR</span>
            <h2>Quét mã để thanh toán vé xem phim</h2>
            <p>Mở ứng dụng ngân hàng, chọn quét QR và kiểm tra đúng số tiền cùng nội dung chuyển khoản trước khi xác nhận.</p>
          </div>

          {confirmed ? (
            <div className="payment-state-panel payment-state-paid">
              <span className="payment-state-icon">✓</span>
              <h3>Thanh toán đã được xác nhận!</h3>
              <p>Admin đã đối soát giao dịch. Mã QR vé xem phim đã được cấp trong Lịch sử vé.</p>
              <Link to="/history" className="btn btn-primary">Xem vé của tôi</Link>
            </div>
          ) : reported ? (
            <div className="payment-state-panel payment-state-reported">
              <span className="payment-state-icon">…</span>
              <h3>Đã ghi nhận thông báo chuyển khoản</h3>
              <p>Rạp đang kiểm tra giao dịch vào tài khoản ngân hàng. Trang này tự cập nhật khi Admin xác nhận.</p>
              <button type="button" className="btn btn-ghost" onClick={() => load(false)}>Kiểm tra lại trạng thái</button>
            </div>
          ) : booking.status === 'expired' || expiredOnClient ? (
            <div className="payment-state-panel payment-state-expired">
              <span className="payment-state-icon">!</span>
              <h3>Đơn thanh toán đã hết hạn</h3>
              <p>Thời gian giữ ghế đã kết thúc. Vui lòng quay lại chọn suất chiếu và ghế mới.</p>
              <Link to="/" className="btn btn-primary">Chọn phim khác</Link>
            </div>
          ) : booking.status === 'payment_rejected' || booking.status === 'cancelled' ? (
            <div className="payment-state-panel payment-state-expired">
              <span className="payment-state-icon">!</span>
              <h3>{statusText}</h3>
              <p>{booking.payment?.rejectionReason || 'Đơn đặt vé không còn hiệu lực thanh toán.'}</p>
              <Link to="/" className="btn btn-primary">Quay lại trang chủ</Link>
            </div>
          ) : payment ? (
            <div className="bank-qr-card">
              <div className="bank-qr-image-wrap">
                <img src={payment.qrImageUrl} alt="Mã QR VietQR thanh toán HTH Cinema" className="bank-qr-image" />
              </div>
              <div className="bank-qr-caption">Mã QR chuyển khoản VietQR</div>
              <div className="bank-payment-amount">{formatMoney(payment.amount)}</div>
              <div className="bank-payment-instructions">Quét mã bằng ứng dụng ngân hàng. Số tiền và nội dung đã được điền sẵn.</div>
              <div className="bank-transfer-details">
                <div><span>Ngân hàng</span><b>{payment.bankId}</b></div>
                <div><span>Số tài khoản</span><b>{payment.accountNo}<button type="button" onClick={() => copyText(payment.accountNo, 'số tài khoản')}>Sao chép</button></b></div>
                <div><span>Chủ tài khoản</span><b>{payment.accountName}</b></div>
                <div><span>Số tiền</span><b>{formatMoney(payment.amount)}<button type="button" onClick={() => copyText(payment.amount, 'số tiền')}>Sao chép</button></b></div>
                <div className="transfer-content-row"><span>Nội dung chuyển khoản</span><b>{payment.transferContent}<button type="button" onClick={() => copyText(payment.transferContent, 'nội dung chuyển khoản')}>Sao chép</button></b></div>
              </div>
              {copyMessage && <div className="payment-copy-message">{copyMessage}</div>}
              <div className="payment-expiry-box">
                <span>Thời gian giữ ghế còn lại</span>
                <strong>{countdown}</strong>
              </div>
              <button type="button" className="bank-payment-reported-button" onClick={notifyTransferred} disabled={reporting || expiredOnClient}>
                {reporting ? 'Đang gửi thông báo...' : 'Tôi đã chuyển khoản'}
              </button>
              <p className="bank-payment-small-note">Chỉ bấm sau khi bạn đã chuyển khoản thành công. HTH Cinema sẽ đối soát tiền vào tài khoản trước khi xác nhận vé.</p>
            </div>
          ) : (
            <div className="payment-state-panel payment-state-expired">
              <h3>Chưa có cấu hình QR thanh toán</h3>
              <p>{error || 'Vui lòng liên hệ quản trị viên để kiểm tra cấu hình VietQR.'}</p>
            </div>
          )}
          <ErrorMessage message={error} />
        </section>

        <aside className="bank-payment-summary">
          <h3>Thông tin đơn đặt vé</h3>
          <span className="payment-order-code">{booking.ticketCode}</span>
          <p><b>Phim:</b> {booking.showtime?.movie?.title || '—'}</p>
          <p><b>Suất chiếu:</b> {booking.showtime ? new Date(booking.showtime.startAt).toLocaleString('vi-VN') : '—'}</p>
          <p><b>Phòng:</b> {booking.showtime?.room?.name || '—'}</p>
          <p><b>Ghế:</b> {booking.seats?.map((seat) => seat.code).join(', ')}</p>
          <p><b>Người đặt:</b> {booking.customer?.name}</p>
          <p><b>Số điện thoại:</b> {booking.customer?.phone}</p>
          <div className="invoice-divider" />
          <div className="invoice-price-row"><span>Tạm tính</span><b>{formatMoney(booking.subtotal)}</b></div>
          {booking.discountAmount > 0 && <div className="invoice-price-row invoice-discount-row"><span>Voucher {booking.voucher?.code}</span><b>−{formatMoney(booking.discountAmount)}</b></div>}
          <div className="invoice-divider" />
          <span className="bank-summary-total-label">Tổng thanh toán</span>
          <strong className="bank-summary-total">{formatMoney(booking.total)}</strong>
          <span className={`bank-payment-status bank-payment-status-${booking.status}`}>{statusText}</span>
          <Link to="/history" className="bank-payment-back-link">Xem lịch sử vé</Link>
        </aside>
      </main>
    </div>
  );
}
