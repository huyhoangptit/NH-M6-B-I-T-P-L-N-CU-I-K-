import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, getApiError } from '../services/api';
import SectionTitle from '../components/SectionTitle';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';

export default function AdminDashboardPage() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');
  const [qrToken, setQrToken] = useState('');
  const [verifyingQr, setVerifyingQr] = useState(false);
  const [verifiedTicket, setVerifiedTicket] = useState(null);
  const [pendingBookings, setPendingBookings] = useState([]);
  const [processingPaymentId, setProcessingPaymentId] = useState('');

  const loadDashboard = useCallback(async () => {
    const [statsResponse, paymentsResponse] = await Promise.all([
      api.get('/admin/stats'),
      api.get('/bookings/admin/pending-payments')
    ]);
    setStats(statsResponse.data.data);
    setPendingBookings(paymentsResponse.data.data.bookings || []);
  }, []);

  useEffect(() => {
    loadDashboard().catch((err) => setError(getApiError(err)));
  }, [loadDashboard]);

  const verifyTicket = async (event) => {
    event.preventDefault();
    setVerifyingQr(true);
    setVerifiedTicket(null);
    setError('');
    try {
      const response = await api.post('/bookings/verify-qr', { qrToken: qrToken.trim() });
      setVerifiedTicket(response.data.data.ticket);
      setQrToken('');
    } catch (err) {
      setError(getApiError(err));
    } finally {
      setVerifyingQr(false);
    }
  };

  const confirmPayment = async (booking) => {
    const confirmed = window.confirm(`Bạn đã kiểm tra tài khoản ngân hàng và xác nhận nhận đủ ${Number(booking.total).toLocaleString('vi-VN')} VNĐ với nội dung ${booking.payment?.transferContent}?`);
    if (!confirmed) return;
    setProcessingPaymentId(booking._id);
    setError('');
    try {
      await api.patch(`/bookings/${booking._id}/confirm-payment`);
      await loadDashboard();
    } catch (err) {
      setError(getApiError(err));
    } finally {
      setProcessingPaymentId('');
    }
  };

  const rejectPayment = async (booking) => {
    const reason = window.prompt('Lý do từ chối (ví dụ: chưa thấy tiền vào, sai số tiền):', 'Chưa xác nhận được giao dịch trong tài khoản ngân hàng.');
    if (reason === null) return;
    setProcessingPaymentId(booking._id);
    setError('');
    try {
      await api.patch(`/bookings/${booking._id}/reject-payment`, { reason });
      await loadDashboard();
    } catch (err) {
      setError(getApiError(err));
    } finally {
      setProcessingPaymentId('');
    }
  };

  return (
    <div className="container section-block">
      <SectionTitle eyebrow="KHU VỰC QUẢN TRỊ" title="Dashboard" description="Quản lý phim, phòng chiếu, suất chiếu, voucher, đối soát thanh toán và doanh thu." />
      <div className="admin-links">
        <Link to="/admin/movies">Quản lý phim →</Link>
        <Link to="/admin/rooms">Quản lý phòng →</Link>
        <Link to="/admin/showtimes">Quản lý suất chiếu →</Link>
        <Link to="/admin/vouchers">Quản lý voucher →</Link>
      </div>

      <section className="panel admin-payment-review-panel">
        <div className="admin-payment-review-heading">
          <div>
            <h3>Đơn chờ xác nhận chuyển khoản</h3>
            <p>Đối chiếu số tiền và nội dung chuyển khoản với giao dịch thực tế trong tài khoản ngân hàng trước khi xác nhận.</p>
          </div>
          <span>{pendingBookings.length} đơn</span>
        </div>
        {pendingBookings.length ? (
          <div className="admin-payment-list">
            {pendingBookings.map((booking) => (
              <article className="admin-payment-item" key={booking._id}>
                <div className="admin-payment-item-main">
                  <b>{booking.ticketCode} · {booking.showtime?.movie?.title || 'Phim'}</b>
                  <span>Khách: {booking.customer?.name} · {booking.customer?.phone}</span>
                  <span>Ghế: {booking.seats.map((seat) => seat.code).join(', ')} · Phòng: {booking.showtime?.room?.name}</span>
                  <span className="admin-payment-transfer-content">Nội dung CK: <strong>{booking.payment?.transferContent}</strong></span>
                  <small>{booking.status === 'payment_reported' ? 'Khách đã bấm “Tôi đã chuyển khoản”.' : 'Đang chờ khách chuyển khoản.'} Hết hạn: {booking.payment?.expiresAt ? new Date(booking.payment.expiresAt).toLocaleString('vi-VN') : '—'}</small>
                </div>
                <div className="admin-payment-item-actions">
                  <strong>{Number(booking.total).toLocaleString('vi-VN')} VNĐ</strong>
                  <button type="button" className="btn btn-primary btn-small" disabled={processingPaymentId === booking._id} onClick={() => confirmPayment(booking)}>Đã nhận tiền</button>
                  <button type="button" className="btn btn-danger btn-small" disabled={processingPaymentId === booking._id} onClick={() => rejectPayment(booking)}>Từ chối</button>
                </div>
              </article>
            ))}
          </div>
        ) : <div className="admin-payment-empty">Hiện không có đơn nào chờ đối soát thanh toán.</div>}
        <button type="button" className="btn btn-ghost btn-small" onClick={() => loadDashboard().catch((err) => setError(getApiError(err)))}>Làm mới danh sách</button>
      </section>

      <section className="panel admin-qr-verify-panel">
        <h3>Xác thực vé bằng mã QR</h3>
        <p>Chỉ quét/xác thực QR vé sau khi đơn đã được xác nhận thanh toán.</p>
        <form onSubmit={verifyTicket} className="admin-qr-verify-form">
          <textarea value={qrToken} onChange={(event) => setQrToken(event.target.value)} placeholder="Dán nội dung mã QR của vé vào đây..." rows="3" required />
          <button className="btn btn-primary" disabled={verifyingQr || !qrToken.trim()}>{verifyingQr ? 'Đang xác thực...' : 'Xác thực vé'}</button>
        </form>
        {verifiedTicket && (
          <div className="admin-qr-verified-result">
            <b>Vé hợp lệ: {verifiedTicket.ticketCode}</b>
            <span>{verifiedTicket.movie} · {verifiedTicket.room}</span>
            <span>Ghế: {verifiedTicket.seats.join(', ')}</span>
            <small>Đã ghi nhận sử dụng lúc {new Date(verifiedTicket.checkedInAt).toLocaleString('vi-VN')}.</small>
          </div>
        )}
      </section>

      <ErrorMessage message={error} />
      {!stats ? <Loading /> : <>
        <div className="stat-grid">
          <div className="stat-card"><span>Vé đã xác nhận thanh toán</span><strong>{stats.summary.totalTickets || 0}</strong></div>
          <div className="stat-card"><span>Doanh thu đã xác nhận</span><strong>{(stats.summary.revenue || 0).toLocaleString('vi-VN')} đ</strong></div>
        </div>
        <SectionTitle title="Doanh thu theo phim" />
        <div className="table-wrap"><table><thead><tr><th>Phim</th><th>Số vé</th><th>Doanh thu</th></tr></thead><tbody>{stats.byMovie.map((item) => <tr key={item._id}><td>{item.title}</td><td>{item.tickets}</td><td>{item.revenue.toLocaleString('vi-VN')} đ</td></tr>)}</tbody></table></div>
        <SectionTitle title="Doanh thu theo ngày" />
        <div className="table-wrap"><table><thead><tr><th>Ngày</th><th>Số vé</th><th>Doanh thu</th></tr></thead><tbody>{stats.byDay.map((item) => <tr key={item._id}><td>{item._id}</td><td>{item.tickets}</td><td>{item.revenue.toLocaleString('vi-VN')} đ</td></tr>)}</tbody></table></div>
      </>}
    </div>
  );
}
