import mongoose from 'mongoose';
const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  showtime: { type: mongoose.Schema.Types.ObjectId, ref: 'Showtime', required: true },
  // Optional at schema level for compatibility with older bookings; POST /bookings validates all three fields.
  customer: {
    name: { type: String, trim: true, minlength: 2, maxlength: 80 },
    phone: { type: String, trim: true, maxlength: 20 },
    email: { type: String, trim: true, lowercase: true, maxlength: 120 }
  },
  seats: [{ code: { type: String, required: true }, type: { type: String, enum: ['normal', 'vip'], required: true }, price: { type: Number, required: true } }],
  subtotal: { type: Number, default: 0, min: 0 },
  discountAmount: { type: Number, default: 0, min: 0 },
  voucher: {
    voucherId: { type: mongoose.Schema.Types.ObjectId, ref: 'Voucher', default: null },
    code: { type: String, default: '' },
    description: { type: String, default: '' }
  },
  voucherUsageReleased: { type: Boolean, default: false },
  payment: {
    method: { type: String, enum: ['vietqr_transfer'], default: 'vietqr_transfer' },
    bankId: { type: String, default: '' },
    accountNo: { type: String, default: '' },
    accountName: { type: String, default: '' },
    transferContent: { type: String, default: '' },
    expiresAt: { type: Date, default: null },
    reportedAt: { type: Date, default: null },
    paidAt: { type: Date, default: null },
    confirmedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    rejectedAt: { type: Date, default: null },
    rejectionReason: { type: String, default: '' }
  },
  total: { type: Number, required: true, min: 0 },
  qrToken: { type: String, default: '' },
  checkedInAt: { type: Date, default: null },
  checkedInBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  status: { type: String, enum: ['pending_payment', 'payment_reported', 'confirmed', 'cancelled', 'expired', 'payment_rejected'], default: 'pending_payment' },
  paymentStatus: { type: String, enum: ['pending', 'reported', 'paid', 'rejected', 'expired'], default: 'paid' },
  ticketCode: { type: String, required: true, unique: true }
}, { timestamps: true });
// Unique multikey index: hai booking đang xác nhận không thể bán cùng một ghế trong một suất.
bookingSchema.index({ showtime: 1, 'seats.code': 1 }, { unique: true, partialFilterExpression: { status: 'confirmed' } });
// Index riêng để pending payment cũng giữ ghế; index cũ được giữ để tương thích database hiện tại.
bookingSchema.index(
  { showtime: 1, 'seats.code': 1 },
  { unique: true, name: 'reserved_showtime_seats_unique', partialFilterExpression: { status: { $in: ['pending_payment', 'payment_reported', 'confirmed'] } } }
);
export const Booking = mongoose.model('Booking', bookingSchema);
