import { ApiError } from './ApiError.js';

export function getVietQrConfig() {
  const bankId = String(process.env.VIETQR_BANK_ID || '').trim();
  const accountNo = String(process.env.VIETQR_ACCOUNT_NO || '').trim();
  const accountName = String(process.env.VIETQR_ACCOUNT_NAME || '').trim();
  if (!bankId || !/^\d{6,19}$/.test(accountNo) || !accountName) {
    throw new ApiError(503, 'Chưa cấu hình tài khoản nhận thanh toán VietQR. Vui lòng kiểm tra VIETQR_BANK_ID, VIETQR_ACCOUNT_NO và VIETQR_ACCOUNT_NAME trong server/.env.');
  }
  return { bankId, accountNo, accountName };
}

export function createTransferContent(ticketCode) {
  // 13 ký tự chữ/số, không dấu, không chứa thông tin cá nhân và đủ ngắn cho VietQR.
  return `HTH${String(ticketCode).replace(/[^A-Z0-9]/gi, '').slice(-10).toUpperCase()}`;
}

export function buildVietQrImageUrl({ bankId, accountNo, accountName, amount, addInfo }) {
  const base = `https://img.vietqr.io/image/${encodeURIComponent(bankId)}-${encodeURIComponent(accountNo)}-compact2.png`;
  const url = new URL(base);
  url.searchParams.set('amount', String(Math.max(0, Math.round(Number(amount) || 0))));
  url.searchParams.set('addInfo', String(addInfo || '').slice(0, 25));
  url.searchParams.set('accountName', accountName);
  return url.toString();
}

export function getPaymentHoldMinutes() {
  const value = Number.parseInt(process.env.PAYMENT_HOLD_MINUTES, 10);
  return Number.isInteger(value) && value >= 5 && value <= 60 ? value : 15;
}
