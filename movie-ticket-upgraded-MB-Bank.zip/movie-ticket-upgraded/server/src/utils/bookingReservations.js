import { Booking } from '../models/Booking.js';
import { Voucher } from '../models/Voucher.js';

export const SEAT_RESERVING_STATUSES = ['pending_payment', 'payment_reported', 'confirmed'];

async function releaseVoucherUsage(voucherId) {
  if (voucherId) {
    await Voucher.updateOne({ _id: voucherId, usedCount: { $gt: 0 } }, { $inc: { usedCount: -1 } });
  }
}

export async function expirePendingBookings() {
  const now = new Date();
  const expired = await Booking.find({
    status: 'pending_payment',
    'payment.expiresAt': { $ne: null, $lte: now },
    'voucher.voucherId': { $exists: true, $ne: null },
    voucherUsageReleased: false
  }).select('_id voucher.voucherId');

  await Booking.updateMany(
    { status: 'pending_payment', 'payment.expiresAt': { $ne: null, $lte: now } },
    { $set: { status: 'expired', paymentStatus: 'expired' } }
  );

  for (const item of expired) {
    // Claim việc hoàn lượt đúng một lần trước khi giảm usedCount.
    const claimed = await Booking.findOneAndUpdate(
      { _id: item._id, voucherUsageReleased: false },
      { $set: { voucherUsageReleased: true } },
      { new: true }
    );
    if (claimed) await releaseVoucherUsage(item.voucher?.voucherId);
  }
}

export async function releaseBookingVoucher(booking) {
  if (!booking?.voucher?.voucherId || booking.voucherUsageReleased) return;
  const claimed = await Booking.findOneAndUpdate(
    { _id: booking._id, voucherUsageReleased: false },
    { $set: { voucherUsageReleased: true } },
    { new: true }
  );
  if (claimed) await releaseVoucherUsage(booking.voucher.voucherId);
}
