import { Router } from 'express';
import { randomBytes } from 'node:crypto';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import { Booking } from '../models/Booking.js';
import { Showtime } from '../models/Showtime.js';
import { Voucher } from '../models/Voucher.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { calculateDiscount, validateVoucherRules } from '../utils/voucher.js';
import { buildVietQrImageUrl, createTransferContent, getPaymentHoldMinutes, getVietQrConfig } from '../utils/vietqr.js';
import { expirePendingBookings, releaseBookingVoucher, SEAT_RESERVING_STATUSES } from '../utils/bookingReservations.js';

const router = Router();
router.use(requireAuth);

function createTicketQrToken(bookingId, ticketCode, showtimeEndAt) {
  const expiryTime = new Date(showtimeEndAt).getTime() + 24 * 60 * 60 * 1000;
  const expiresIn = Math.max(60, Math.floor((expiryTime - Date.now()) / 1000));
  return jwt.sign(
    { purpose: 'hth-cinema-ticket', bookingId: String(bookingId), ticketCode },
    process.env.JWT_SECRET,
    { expiresIn }
  );
}

function getPaymentView(booking) {
  const payment = booking.payment || {};
  const amount = Number(booking.total || 0);
  return {
    method: payment.method || 'vietqr_transfer',
    bankId: payment.bankId,
    accountNo: payment.accountNo,
    accountName: payment.accountName,
    amount,
    transferContent: payment.transferContent,
    expiresAt: payment.expiresAt,
    qrImageUrl: buildVietQrImageUrl({
      bankId: payment.bankId,
      accountNo: payment.accountNo,
      accountName: payment.accountName,
      amount,
      addInfo: payment.transferContent
    })
  };
}

router.post('/', asyncHandler(async (req, res) => {
  await expirePendingBookings();
  const { showtimeId, seats, customer, voucherCode: rawVoucherCode } = req.body;
  if (!customer || typeof customer.name !== 'string' || customer.name.trim().length < 2 || typeof customer.phone !== 'string' || !/^[0-9+ .()\-]{9,18}$/.test(customer.phone.trim()) || typeof customer.email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email.trim())) {
    throw new ApiError(400, 'Vui lòng nhập họ tên, số điện thoại và email hợp lệ của người đặt.');
  }
  if (!showtimeId || !Array.isArray(seats) || !seats.length) throw new ApiError(400, 'Vui lòng chọn suất chiếu và ít nhất một ghế.');
  if (seats.length > 8) throw new ApiError(400, 'Mỗi lần chỉ được đặt tối đa 8 ghế.');
  if (new Set(seats).size !== seats.length || seats.some((seat) => typeof seat !== 'string')) throw new ApiError(400, 'Danh sách ghế không hợp lệ.');

  const bankConfig = getVietQrConfig();
  const showtime = await Showtime.findById(showtimeId).populate('room').populate('movie');
  if (!showtime || !showtime.active) throw new ApiError(404, 'Không tìm thấy suất chiếu.');
  if (showtime.startAt <= new Date()) throw new ApiError(400, 'Suất chiếu đã bắt đầu hoặc đã qua.');

  const rowNames = Array.from({ length: showtime.room.rows }, (_, index) => String.fromCharCode(65 + index));
  const validSeats = new Set(rowNames.flatMap((row) => Array.from({ length: showtime.room.seatsPerRow }, (_, index) => `${row}${index + 1}`)));
  const invalidSeats = seats.filter((seat) => !validSeats.has(seat));
  if (invalidSeats.length) throw new ApiError(400, `Ghế không tồn tại: ${invalidSeats.join(', ')}`);

  const occupied = await Booking.distinct('seats.code', {
    showtime: showtime._id,
    status: { $in: SEAT_RESERVING_STATUSES },
    'seats.code': { $in: seats }
  });
  if (occupied.length) {
    res.status(409).json({ success: false, message: `Ghế ${occupied.join(', ')} vừa được người khác giữ hoặc đặt.`, conflictSeats: occupied });
    return;
  }

  const seatDetails = seats.map((code) => {
    const type = showtime.room.vipRows.includes(code[0]) ? 'vip' : 'normal';
    return { code, type, price: type === 'vip' ? showtime.priceVip : showtime.priceNormal };
  });
  const subtotal = seatDetails.reduce((sum, seat) => sum + seat.price, 0);

  let selectedVoucher = null;
  let discountAmount = 0;
  let reservedVoucherId = null;
  const voucherCode = String(rawVoucherCode || '').trim().toUpperCase();

  if (voucherCode) {
    selectedVoucher = await Voucher.findOne({ code: voucherCode });
    validateVoucherRules(selectedVoucher, subtotal);
    const reservedVoucher = await Voucher.findOneAndUpdate(
      {
        _id: selectedVoucher._id,
        isActive: true,
        startsAt: { $lte: new Date() },
        expiresAt: { $gte: new Date() },
        minOrderValue: { $lte: subtotal },
        $or: [
          { usageLimit: null },
          { $expr: { $lt: ['$usedCount', '$usageLimit'] } }
        ]
      },
      { $inc: { usedCount: 1 } },
      { new: true }
    );
    if (!reservedVoucher) throw new ApiError(400, 'Voucher vừa hết lượt sử dụng hoặc không còn hiệu lực. Vui lòng kiểm tra lại.');
    selectedVoucher = reservedVoucher;
    reservedVoucherId = reservedVoucher._id;
    discountAmount = calculateDiscount(reservedVoucher, subtotal);
  }

  const total = Math.max(0, subtotal - discountAmount);
  if (total < 1000) {
    if (reservedVoucherId) await Voucher.updateOne({ _id: reservedVoucherId, usedCount: { $gt: 0 } }, { $inc: { usedCount: -1 } });
    throw new ApiError(400, 'Số tiền sau khi áp dụng voucher phải từ 1.000 VNĐ để tạo QR chuyển khoản.');
  }
  const ticketCode = `HTH-${randomBytes(5).toString('hex').toUpperCase()}`;
  const transferContent = createTransferContent(ticketCode);
  const bookingId = new mongoose.Types.ObjectId();
  const now = Date.now();
  const requestedExpiry = now + getPaymentHoldMinutes() * 60 * 1000;
  const latestExpiry = new Date(showtime.startAt).getTime() - 60 * 1000;
  const expiresAt = new Date(Math.min(requestedExpiry, latestExpiry));
  if (expiresAt.getTime() <= now) {
    if (reservedVoucherId) await Voucher.updateOne({ _id: reservedVoucherId, usedCount: { $gt: 0 } }, { $inc: { usedCount: -1 } });
    throw new ApiError(400, 'Suất chiếu sắp bắt đầu, không còn đủ thời gian để tạo đơn chuyển khoản. Vui lòng chọn suất khác.');
  }

  try {
    const booking = await Booking.create({
      _id: bookingId,
      user: req.user._id,
      showtime: showtime._id,
      customer: {
        name: customer.name.trim(),
        phone: customer.phone.trim(),
        email: customer.email.trim().toLowerCase()
      },
      seats: seatDetails,
      subtotal,
      discountAmount,
      voucher: selectedVoucher ? {
        voucherId: selectedVoucher._id,
        code: selectedVoucher.code,
        description: selectedVoucher.description
      } : undefined,
      total,
      status: 'pending_payment',
      paymentStatus: 'pending',
      payment: {
        method: 'vietqr_transfer',
        bankId: bankConfig.bankId,
        accountNo: bankConfig.accountNo,
        accountName: bankConfig.accountName,
        transferContent,
        expiresAt
      },
      ticketCode,
      qrToken: ''
    });
    res.status(201).json({
      success: true,
      message: 'Đã tạo đơn đặt vé. Vui lòng quét VietQR và chuyển khoản trong thời hạn giữ ghế.',
      data: {
        booking,
        payment: {
          bankId: bankConfig.bankId,
          accountNo: bankConfig.accountNo,
          accountName: bankConfig.accountName,
          amount: total,
          transferContent,
          expiresAt,
          qrImageUrl: buildVietQrImageUrl({ ...bankConfig, amount: total, addInfo: transferContent })
        }
      }
    });
  } catch (error) {
    if (reservedVoucherId) await Voucher.updateOne({ _id: reservedVoucherId, usedCount: { $gt: 0 } }, { $inc: { usedCount: -1 } });
    if (error.code === 11000) {
      const latest = await Booking.distinct('seats.code', {
        showtime: showtime._id,
        status: { $in: SEAT_RESERVING_STATUSES },
        'seats.code': { $in: seats }
      });
      res.status(409).json({ success: false, message: `Ghế ${latest.join(', ')} vừa được người khác giữ hoặc đặt.`, conflictSeats: latest });
      return;
    }
    throw error;
  }
}));

router.get('/my', asyncHandler(async (req, res) => {
  await expirePendingBookings();
  const bookings = await Booking.find({ user: req.user._id })
    .populate({ path: 'showtime', populate: [{ path: 'movie', select: 'title posterUrl' }, { path: 'room', select: 'name' }] })
    .sort({ createdAt: -1 });

  // Vé cũ đã thanh toán nhưng chưa được cấp QR sẽ được cấp khi mở lịch sử.
  for (const booking of bookings) {
    const qrValidUntil = booking.showtime?.endAt
      ? new Date(booking.showtime.endAt).getTime() + 24 * 60 * 60 * 1000
      : 0;
    if (booking.status === 'confirmed' && !booking.qrToken && qrValidUntil > Date.now()) {
      booking.qrToken = createTicketQrToken(booking._id, booking.ticketCode, booking.showtime.endAt);
      await booking.save();
    }
  }
  res.json({ success: true, data: { bookings } });
}));

router.get('/admin/pending-payments', requireRole('admin'), asyncHandler(async (req, res) => {
  await expirePendingBookings();
  const bookings = await Booking.find({ status: { $in: ['pending_payment', 'payment_reported'] } })
    .populate('user', 'name email')
    .populate({ path: 'showtime', populate: [{ path: 'movie', select: 'title' }, { path: 'room', select: 'name' }] })
    .sort({ createdAt: 1 });
  res.json({ success: true, data: { bookings } });
}));

router.get('/:id/payment', asyncHandler(async (req, res) => {
  await expirePendingBookings();
  if (!mongoose.isValidObjectId(req.params.id)) throw new ApiError(400, 'Mã đơn đặt vé không hợp lệ.');
  const booking = await Booking.findById(req.params.id)
    .populate({ path: 'showtime', populate: [{ path: 'movie', select: 'title' }, { path: 'room', select: 'name' }] });
  if (!booking) throw new ApiError(404, 'Không tìm thấy đơn đặt vé.');
  if (booking.user.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    throw new ApiError(403, 'Bạn không có quyền xem thông tin thanh toán của đơn này.');
  }
  const payment = booking.payment?.bankId && booking.payment?.accountNo
    ? getPaymentView(booking)
    : null;
  res.json({ success: true, data: { booking, payment } });
}));

router.post('/:id/notify-payment', asyncHandler(async (req, res) => {
  await expirePendingBookings();
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw new ApiError(404, 'Không tìm thấy đơn đặt vé.');
  if (booking.user.toString() !== req.user._id.toString()) throw new ApiError(403, 'Bạn không có quyền báo thanh toán cho đơn này.');
  if (booking.status === 'payment_reported') {
    res.json({ success: true, message: 'Bạn đã báo chuyển khoản. Rạp đang đối soát giao dịch.', data: { booking } });
    return;
  }
  if (booking.status !== 'pending_payment' || !booking.payment?.expiresAt || booking.payment.expiresAt <= new Date()) {
    throw new ApiError(400, 'Đơn đã hết hạn hoặc không còn ở trạng thái chờ thanh toán.');
  }
  const updated = await Booking.findOneAndUpdate(
    { _id: booking._id, status: 'pending_payment', 'payment.expiresAt': { $gt: new Date() } },
    { $set: { status: 'payment_reported', paymentStatus: 'reported', 'payment.reportedAt': new Date() } },
    { new: true }
  );
  if (!updated) throw new ApiError(409, 'Trạng thái đơn vừa thay đổi. Vui lòng tải lại trang.');
  res.json({ success: true, message: 'Đã ghi nhận thông báo chuyển khoản. Vé sẽ được xác nhận sau khi Admin đối soát tiền vào tài khoản.', data: { booking: updated } });
}));

router.patch('/:id/confirm-payment', requireRole('admin'), asyncHandler(async (req, res) => {
  await expirePendingBookings();
  if (!mongoose.isValidObjectId(req.params.id)) throw new ApiError(400, 'Mã đơn đặt vé không hợp lệ.');
  const booking = await Booking.findOne({
    _id: req.params.id,
    $or: [
      { status: 'payment_reported' },
      { status: 'pending_payment', 'payment.expiresAt': { $gt: new Date() } }
    ]
  }).populate({ path: 'showtime', populate: [{ path: 'movie', select: 'title' }, { path: 'room', select: 'name' }] });
  if (!booking) throw new ApiError(400, 'Đơn không còn hiệu lực thanh toán hoặc đã được xử lý.');
  if (!booking.showtime) throw new ApiError(404, 'Không tìm thấy suất chiếu của đơn này.');
  if (booking.showtime.startAt <= new Date()) throw new ApiError(400, 'Suất chiếu đã bắt đầu. Không thể phát hành vé; Admin cần xử lý khoản chuyển đến theo quy định của rạp.');

  const paidAt = new Date();
  const qrToken = createTicketQrToken(booking._id, booking.ticketCode, booking.showtime.endAt);
  const confirmed = await Booking.findOneAndUpdate(
    { _id: booking._id, $or: [
      { status: 'payment_reported' },
      { status: 'pending_payment', 'payment.expiresAt': { $gt: paidAt } }
    ] },
    { $set: { status: 'confirmed', paymentStatus: 'paid', 'payment.paidAt': paidAt, 'payment.confirmedBy': req.user._id, qrToken } },
    { new: true }
  );
  if (!confirmed) throw new ApiError(409, 'Đơn vừa được xử lý bởi người khác. Hãy tải lại danh sách.');
  res.json({ success: true, message: `Đã xác nhận thanh toán cho vé ${confirmed.ticketCode}. QR vé đã được cấp.`, data: { booking: confirmed } });
}));

router.patch('/:id/reject-payment', requireRole('admin'), asyncHandler(async (req, res) => {
  await expirePendingBookings();
  if (!mongoose.isValidObjectId(req.params.id)) throw new ApiError(400, 'Mã đơn đặt vé không hợp lệ.');
  const reason = String(req.body.reason || 'Không xác nhận được giao dịch chuyển khoản.').trim().slice(0, 250);
  const rejected = await Booking.findOneAndUpdate(
    { _id: req.params.id, status: { $in: ['pending_payment', 'payment_reported'] } },
    { $set: { status: 'payment_rejected', paymentStatus: 'rejected', 'payment.rejectedAt': new Date(), 'payment.rejectionReason': reason } },
    { new: true }
  );
  if (!rejected) throw new ApiError(400, 'Đơn không còn ở trạng thái chờ xác nhận thanh toán.');
  await releaseBookingVoucher(rejected);
  res.json({ success: true, message: `Đã từ chối thanh toán đơn ${rejected.ticketCode}; ghế được giải phóng.`, data: { booking: rejected } });
}));

// Admin quét QR vé sau khi đã xác nhận tiền vào tài khoản.
router.post('/verify-qr', requireRole('admin'), asyncHandler(async (req, res) => {
  const qrToken = String(req.body.qrToken || '').trim();
  if (!qrToken) throw new ApiError(400, 'Vui lòng nhập dữ liệu QR của vé.');

  let payload;
  try {
    payload = jwt.verify(qrToken, process.env.JWT_SECRET);
  } catch {
    throw new ApiError(400, 'Mã QR không hợp lệ hoặc đã hết hạn.');
  }
  if (payload.purpose !== 'hth-cinema-ticket' || !mongoose.isValidObjectId(payload.bookingId)) {
    throw new ApiError(400, 'Mã QR không thuộc hệ thống HTH Cinema.');
  }

  const booking = await Booking.findById(payload.bookingId)
    .populate({ path: 'showtime', populate: [{ path: 'movie', select: 'title' }, { path: 'room', select: 'name' }] });
  if (!booking || booking.ticketCode !== payload.ticketCode) throw new ApiError(404, 'Không tìm thấy vé tương ứng với mã QR.');
  if (!booking.showtime) throw new ApiError(404, 'Suất chiếu gắn với vé này không còn tồn tại.');
  if (booking.status !== 'confirmed' || (booking.paymentStatus && booking.paymentStatus !== 'paid')) throw new ApiError(400, 'Vé chưa được xác nhận thanh toán hoặc đã bị hủy.');
  const entryOpensAt = booking.showtime.startAt.getTime() - 2 * 60 * 60 * 1000;
  if (Date.now() < entryOpensAt) throw new ApiError(400, 'Vé chỉ được xác thực trong vòng 2 tiếng trước giờ chiếu.');
  if (booking.checkedInAt) throw new ApiError(409, `Vé này đã được sử dụng lúc ${booking.checkedInAt.toLocaleString('vi-VN')}.`);

  const checkedInAt = new Date();
  const checkedInBooking = await Booking.findOneAndUpdate(
    { _id: booking._id, status: 'confirmed', $or: [{ paymentStatus: 'paid' }, { paymentStatus: { $exists: false } }, { paymentStatus: null }], checkedInAt: null },
    { $set: { checkedInAt, checkedInBy: req.user._id } },
    { new: true }
  );
  if (!checkedInBooking) {
    const latest = await Booking.findById(booking._id).select('checkedInAt status');
    if (latest?.checkedInAt) throw new ApiError(409, `Vé này vừa được sử dụng lúc ${latest.checkedInAt.toLocaleString('vi-VN')}.`);
    throw new ApiError(400, 'Vé không còn ở trạng thái có thể sử dụng.');
  }
  res.json({
    success: true,
    message: 'Xác thực QR thành công. Vé đã được ghi nhận sử dụng.',
    data: {
      ticket: {
        ticketCode: booking.ticketCode,
        movie: booking.showtime?.movie?.title,
        room: booking.showtime?.room?.name,
        seats: booking.seats.map((seat) => seat.code),
        checkedInAt: checkedInBooking.checkedInAt
      }
    }
  });
}));

router.patch('/:id/cancel', asyncHandler(async (req, res) => {
  await expirePendingBookings();
  const booking = await Booking.findById(req.params.id).populate('showtime');
  if (!booking) throw new ApiError(404, 'Không tìm thấy vé.');
  const isOwner = booking.user.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== 'admin') throw new ApiError(403, 'Bạn không có quyền hủy vé này.');
  if (!['pending_payment', 'payment_reported', 'confirmed'].includes(booking.status)) throw new ApiError(400, 'Vé này không còn ở trạng thái có thể hủy.');
  if (booking.status === 'payment_reported' && req.user.role !== 'admin') throw new ApiError(400, 'Đơn đã báo chuyển khoản. Vui lòng chờ Admin đối soát hoặc liên hệ rạp để xử lý hủy đơn.');
  if (booking.checkedInAt) throw new ApiError(400, 'Vé đã được sử dụng, không thể hủy.');
  const twoHours = 2 * 60 * 60 * 1000;
  if (!booking.showtime || booking.showtime.startAt.getTime() - Date.now() < twoHours) throw new ApiError(400, 'Chỉ được hủy vé trước giờ chiếu ít nhất 2 tiếng.');
  booking.status = 'cancelled';
  await booking.save();
  await releaseBookingVoucher(booking);
  res.json({ success: true, data: { booking }, message: 'Đã hủy đơn đặt vé. Ghế được giải phóng.' });
}));

export default router;
