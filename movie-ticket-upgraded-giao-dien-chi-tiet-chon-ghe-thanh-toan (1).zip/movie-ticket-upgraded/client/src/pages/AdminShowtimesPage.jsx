import { useEffect, useMemo, useState } from 'react';
import { api, getApiError } from '../services/api';
import SectionTitle from '../components/SectionTitle';
import ErrorMessage from '../components/ErrorMessage';

const emptyForm = { movieId: '', roomId: '', startAt: '', priceNormal: 80000, priceVip: 110000 };

export default function AdminShowtimesPage() {
  const [movies, setMovies] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [showtimes, setShowtimes] = useState([]);
  const [error, setError] = useState('');
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);

  const assignedRoomId = useMemo(() => {
    const movie = movies.find((item) => item._id === form.movieId);
    const existing = showtimes.find((item) => item.movie?._id === form.movieId);
    return movie?.defaultRoom || existing?.room?._id || '';
  }, [movies, showtimes, form.movieId]);

  const load = async () => {
    const [movieResponse, roomResponse, showtimeResponse] = await Promise.all([
      api.get('/movies', { params: { limit: 100 } }),
      api.get('/rooms'),
      api.get('/showtimes', { params: { limit: 500 } })
    ]);
    setMovies(movieResponse.data.data.movies);
    setRooms(roomResponse.data.data.rooms);
    setShowtimes(showtimeResponse.data.data.showtimes);
  };

  useEffect(() => { load().catch((err) => setError(getApiError(err))); }, []);

  useEffect(() => {
    if (assignedRoomId && form.roomId !== assignedRoomId) {
      setForm((current) => ({ ...current, roomId: assignedRoomId }));
    }
  }, [assignedRoomId, form.roomId]);

  const update = (event) => {
    const { name, value } = event.target;
    setForm((old) => ({ ...old, [name]: value }));
  };

  const submit = async (event) => {
    event.preventDefault();
    setError('');
    try {
      const payload = {
        ...form,
        startAt: new Date(form.startAt).toISOString(),
        priceNormal: Number(form.priceNormal),
        priceVip: Number(form.priceVip)
      };
      if (editingId) await api.put(`/showtimes/${editingId}`, payload);
      else await api.post('/showtimes', payload);
      setForm(emptyForm);
      setEditingId(null);
      await load();
    } catch (err) {
      setError(err?.response?.status === 409
        ? (err.response.data.message || 'Phòng chiếu đã được gán cho phim khác hoặc khung giờ bị trùng.')
        : getApiError(err));
    }
  };

  const edit = (item) => {
    const localDate = new Date(new Date(item.startAt).getTime() - new Date(item.startAt).getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    setEditingId(item._id);
    setForm({
      movieId: item.movie?._id || '',
      roomId: item.room?._id || '',
      startAt: localDate,
      priceNormal: item.priceNormal,
      priceVip: item.priceVip
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const remove = async (id) => {
    if (!window.confirm('Xóa suất chiếu?')) return;
    try {
      await api.delete(`/showtimes/${id}`);
      await load();
    } catch (err) { setError(getApiError(err)); }
  };

  const cancelEdit = () => { setEditingId(null); setForm(emptyForm); };

  return (
    <div className="container section-block">
      <SectionTitle title="Quản lý suất chiếu" description="Mỗi phim chỉ được gán một phòng cố định. Bạn có thể tạo nhiều khung giờ và ngày chiếu cho phim đó." />
      <ErrorMessage message={error} />
      <form className="panel admin-form" onSubmit={submit}>
        <div className="form-grid">
          <label>Phim
            <select name="movieId" value={form.movieId} onChange={(event) => setForm((old) => ({ ...old, movieId: event.target.value, roomId: '' }))} required>
              <option value="">Chọn phim</option>
              {movies.map((movie) => <option value={movie._id} key={movie._id}>{movie.title}</option>)}
            </select>
          </label>
          <label>Phòng chiếu
            <select name="roomId" value={form.roomId} onChange={update} required disabled={Boolean(assignedRoomId)}>
              <option value="">Chọn phòng</option>
              {rooms.map((room) => <option value={room._id} key={room._id}>{room.name}</option>)}
            </select>
            {assignedRoomId && <small className="assigned-room-note">Phim này đã được cố định tại {rooms.find((room) => room._id === assignedRoomId)?.name || 'phòng đã chọn'}.</small>}
          </label>
          <label>Ngày giờ chiếu<input type="datetime-local" name="startAt" value={form.startAt} onChange={update} required /></label>
          <label>Giá ghế thường<input type="number" min="0" name="priceNormal" value={form.priceNormal} onChange={update} required /></label>
          <label>Giá ghế VIP<input type="number" min="0" name="priceVip" value={form.priceVip} onChange={update} required /></label>
        </div>
        <button className="btn btn-primary">{editingId ? 'Lưu thay đổi' : 'Tạo suất chiếu'}</button>
        {editingId && <button type="button" className="btn btn-ghost" onClick={cancelEdit}>Hủy sửa</button>}
      </form>

      <div className="table-wrap">
        <table>
          <thead><tr><th>Phim</th><th>Phòng</th><th>Bắt đầu</th><th>Kết thúc</th><th></th></tr></thead>
          <tbody>
            {showtimes.map((item) => (
              <tr key={item._id}>
                <td>{item.movie?.title}</td>
                <td>{item.room?.name}</td>
                <td>{new Date(item.startAt).toLocaleString('vi-VN')}</td>
                <td>{new Date(item.endAt).toLocaleString('vi-VN')}</td>
                <td><div className="table-actions"><button className="btn btn-ghost btn-small" onClick={() => edit(item)}>Sửa</button><button className="btn btn-danger btn-small" onClick={() => remove(item._id)}>Xóa</button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
