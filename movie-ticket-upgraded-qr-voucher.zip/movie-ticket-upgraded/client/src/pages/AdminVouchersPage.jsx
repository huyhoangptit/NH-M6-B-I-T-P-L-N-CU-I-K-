import { useEffect, useMemo, useState } from 'react';
import { api, getApiError } from '../services/api';
import SectionTitle from '../components/SectionTitle';
import ErrorMessage from '../components/ErrorMessage';

function toLocalDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

function createEmptyForm() {
  const now = new Date();
  const end = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  return {
    code: '', description: '', discountType: 'percent', discountValue: 10,
    maxDiscount: 50000, minOrderValue: 100000,
    startsAt: toLocalDateTime(now), expiresAt: toLocalDateTime(end),
    usageLimit: 100, isActive: true
  };
}

export default function AdminVouchersPage() {
  const [vouchers, setVouchers] = useState([]);
  const [form, setForm] = useState(createEmptyForm);
  const [editingId, setEditingId] = useState(null);
  const [keyword, setKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const response = await api.get('/vouchers');
    setVouchers(response.data.data.vouchers || []);
  };

  useEffect(() => {
    load().catch((err) => setError(getApiError(err))).finally(() => setLoading(false));
  }, []);

  const filteredVouchers = useMemo(() => {
    const text = keyword.trim().toLocaleLowerCase('vi');
    return vouchers.filter((voucher) => {
      const matchesText = !text
        || voucher.code.toLocaleLowerCase('vi').includes(text)
        || (voucher.description || '').toLocaleLowerCase('vi').includes(text);
      const expired = new Date(voucher.expiresAt) < new Date();
      const matchesStatus = statusFilter === 'all'
        || (statusFilter === 'active' && voucher.isActive && !expired)
        || (statusFilter === 'inactive' && (!voucher.isActive || expired));
      return matchesText && matchesStatus;
    });
  }, [vouchers, keyword, statusFilter]);

  const update = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const submit = async (event) => {
    event.preventDefault();
    setError('');
    try {
      const payload = {
        ...form,
        code: form.code.trim().toUpperCase(),
        discountValue: Number(form.discountValue),
        maxDiscount: form.discountType === 'percent' && form.maxDiscount !== '' ? Number(form.maxDiscount) : null,
        minOrderValue: Number(form.minOrderValue || 0),
        usageLimit: form.usageLimit === '' ? null : Number(form.usageLimit),
        startsAt: new Date(form.startsAt).toISOString(),
        expiresAt: new Date(form.expiresAt).toISOString()
      };
      if (editingId) await api.put(`/vouchers/${editingId}`, payload);
      else await api.post('/vouchers', payload);
      setForm(createEmptyForm());
      setEditingId(null);
      await load();
    } catch (err) {
      setError(getApiError(err));
    }
  };

  const edit = (voucher) => {
    setEditingId(voucher._id);
    setForm({
      code: voucher.code,
      description: voucher.description || '',
      discountType: voucher.discountType,
      discountValue: voucher.discountValue,
      maxDiscount: voucher.maxDiscount ?? '',
      minOrderValue: voucher.minOrderValue ?? 0,
      startsAt: toLocalDateTime(voucher.startsAt),
      expiresAt: toLocalDateTime(voucher.expiresAt),
      usageLimit: voucher.usageLimit ?? '',
      isActive: voucher.isActive
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const remove = async (id) => {
    if (!window.confirm('Bạn có chắc muốn xóa voucher này?')) return;
    try {
      await api.delete(`/vouchers/${id}`);
      await load();
    } catch (err) {
      setError(getApiError(err));
    }
  };

  const resetForm = () => { setEditingId(null); setForm(createEmptyForm()); };

  return (
    <div className="container section-block">
      <SectionTitle title="Quản lý voucher" description="Tạo mã giảm giá, đặt điều kiện đơn hàng, thời hạn và số lượt sử dụng." />
      <ErrorMessage message={error} />

      <form className="panel admin-form voucher-admin-form" onSubmit={submit}>
        <h3>{editingId ? 'Chỉnh sửa voucher' : 'Tạo voucher mới'}</h3>
        <div className="form-grid">
          <label>Mã voucher<input name="code" value={form.code} onChange={update} placeholder="Ví dụ: HTH10" minLength="3" maxLength="30" pattern="[A-Za-z0-9_-]{3,30}" required /></label>
          <label>Loại giảm giá<select name="discountType" value={form.discountType} onChange={update}><option value="percent">Theo phần trăm (%)</option><option value="fixed">Số tiền cố định (VNĐ)</option></select></label>
          <label>{form.discountType === 'percent' ? 'Phần trăm giảm (%)' : 'Số tiền giảm (VNĐ)'}<input name="discountValue" type="number" min="1" max={form.discountType === 'percent' ? 100 : undefined} value={form.discountValue} onChange={update} required /></label>
          {form.discountType === 'percent' && <label>Giảm tối đa (VNĐ, bỏ trống = không giới hạn)<input name="maxDiscount" type="number" min="1" value={form.maxDiscount} onChange={update} /></label>}
          <label>Đơn hàng tối thiểu (VNĐ)<input name="minOrderValue" type="number" min="0" value={form.minOrderValue} onChange={update} required /></label>
          <label>Số lượt sử dụng (bỏ trống = không giới hạn)<input name="usageLimit" type="number" min="1" value={form.usageLimit} onChange={update} /></label>
          <label>Bắt đầu lúc<input name="startsAt" type="datetime-local" value={form.startsAt} onChange={update} required /></label>
          <label>Hết hạn lúc<input name="expiresAt" type="datetime-local" min={form.startsAt || undefined} value={form.expiresAt} onChange={update} required /></label>
          <label className="wide">Mô tả voucher<input name="description" value={form.description} onChange={update} maxLength="250" placeholder="Điều kiện hoặc nội dung ưu đãi..." /></label>
          <label className="voucher-active-toggle"><input name="isActive" type="checkbox" checked={form.isActive} onChange={update} /> Cho phép sử dụng</label>
        </div>
        <button className="btn btn-primary">{editingId ? 'Lưu thay đổi' : 'Tạo voucher'}</button>
        {editingId && <button type="button" className="btn btn-ghost" onClick={resetForm}>Hủy sửa</button>}
      </form>

      <section className="panel admin-filter-panel">
        <div className="admin-filter-heading"><div><h3>Tìm kiếm voucher</h3><p>Lọc nhanh theo mã, mô tả và trạng thái.</p></div><span>{filteredVouchers.length}/{vouchers.length} mã</span></div>
        <div className="admin-filter-grid voucher-filter-grid">
          <label className="filter-search">Tìm mã voucher<input value={keyword} onChange={(event) => setKeyword(event.target.value)} placeholder="Nhập mã hoặc mô tả..." /></label>
          <label>Trạng thái<select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="all">Tất cả</option><option value="active">Đang hoạt động</option><option value="inactive">Đã tắt / hết hạn</option></select></label>
          <button type="button" className="btn btn-ghost filter-reset" onClick={() => { setKeyword(''); setStatusFilter('all'); }}>Xóa bộ lọc</button>
        </div>
      </section>

      <div className="table-wrap">
        <table>
          <thead><tr><th>Mã</th><th>Mức giảm</th><th>Đơn tối thiểu</th><th>Lượt đã dùng</th><th>Hạn dùng</th><th>Trạng thái</th><th></th></tr></thead>
          <tbody>
            {filteredVouchers.map((voucher) => {
              const expired = new Date(voucher.expiresAt) < new Date();
              const isUsable = voucher.isActive && !expired && (voucher.usageLimit == null || voucher.usedCount < voucher.usageLimit);
              return <tr key={voucher._id}>
                <td><b>{voucher.code}</b><br /><small>{voucher.description}</small></td>
                <td>{voucher.discountType === 'percent' ? `${voucher.discountValue}%${voucher.maxDiscount ? ` (tối đa ${Number(voucher.maxDiscount).toLocaleString('vi-VN')} đ)` : ''}` : `${Number(voucher.discountValue).toLocaleString('vi-VN')} đ`}</td>
                <td>{Number(voucher.minOrderValue).toLocaleString('vi-VN')} đ</td>
                <td>{voucher.usedCount}/{voucher.usageLimit ?? '∞'}</td>
                <td>{new Date(voucher.expiresAt).toLocaleString('vi-VN')}</td>
                <td><span className={`status-pill ${isUsable ? 'confirmed' : 'cancelled'}`}>{isUsable ? 'Đang hoạt động' : 'Không hoạt động'}</span></td>
                <td><div className="table-actions"><button className="btn btn-ghost btn-small" onClick={() => edit(voucher)}>Sửa</button><button className="btn btn-danger btn-small" onClick={() => remove(voucher._id)}>Xóa</button></div></td>
              </tr>;
            })}
            {!loading && !filteredVouchers.length && <tr><td colSpan="7" className="admin-empty-cell">Không tìm thấy voucher phù hợp.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
