import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { api, getApiError } from '../services/api';
import SectionTitle from '../components/SectionTitle';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';

export default function HistoryPage() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const location = useLocation();

  const load = async () => {
    try {
      const response = await api.get('/bookings/my');
      setBookings(response.data.data.bookings);
    } catch (err) {
      setError(getApiError(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const cancel = async (id) => {
    if (!window.confirm('Bạn chắc chắn muốn hủy vé này?')) return;
    try {
      await api.patch(`/bookings/${id}/cancel`);
      await load();
    } catch (err) {
      setError(getApiError(err));
    }
  };

  return (
    <div className="container section-block">
      <SectionTitle eyebrow="TÀI KHOẢN" title="Lịch sử vé" description="Mỗi vé có mã QR riêng để đối chiếu tại rạp. Mở phần QR trên vé để xem hoặc in vé." />
      {location.state?.success && <div className="alert alert-success">{location.state.success}</div>}
      <ErrorMessage message={error} />
      {loading ? <Loading /> : bookings.length ? (
        <div className="ticket-list">
          {bookings.map((booking) => {
            const start = new Date(booking.showtime?.startAt);
            const canCancel = booking.status === 'confirmed'
              && !booking.checkedInAt
              && start.getTime() - Date.now() >= 2 * 60 * 60 * 1000;
            const qrStillValid = booking.showtime?.endAt
              ? new Date(booking.showtime.endAt).getTime() + 24 * 60 * 60 * 1000 > Date.now()
              : false;
            return (
              <article className="ticket-card ticket-card-with-qr" key={booking._id}>
                <div className="ticket-main-info">
                  <span className="eyebrow">MÃ VÉ {booking.ticketCode}</span>
                  <h3>{booking.showtime?.movie?.title || 'Phim'}</h3>
                  <p>{start.toLocaleString('vi-VN')} · {booking.showtime?.room?.name}</p>
                  <p>Ghế: {booking.seats.map((seat) => seat.code).join(', ')}</p>
                  {booking.customer?.name && <p>Người đặt: {booking.customer.name}</p>}
                  {booking.voucher?.code && <p>Voucher: <b className="invoice-seats">{booking.voucher.code}</b> · Giảm {Number(booking.discountAmount || 0).toLocaleString('vi-VN')} đ</p>}
                  {booking.checkedInAt && <p className="ticket-checked-in">Đã sử dụng lúc {new Date(booking.checkedInAt).toLocaleString('vi-VN')}</p>}
                </div>
                <div className="ticket-side">
                  <b>{booking.total.toLocaleString('vi-VN')} đ</b>
                  <span className={`status-pill ${booking.status}`}>{booking.status === 'confirmed' ? 'Đã xác nhận' : 'Đã hủy'}</span>
                  {booking.status === 'confirmed' && !booking.checkedInAt && booking.qrToken && qrStillValid && (
                    <details className="ticket-qr-details">
                      <summary>Hiển thị mã QR vé</summary>
                      <div className="ticket-qr-content">
                        <QRCodeSVG value={booking.qrToken} size={164} level="H" includeMargin bgColor="#ffffff" fgColor="#111111" />
                        <b>{booking.ticketCode}</b>
                        <strong>{booking.showtime?.movie?.title || 'Vé xem phim'}</strong>
                        <small>{start.toLocaleString('vi-VN')} · {booking.showtime?.room?.name}</small>
                        <small>Ghế: {booking.seats.map((seat) => seat.code).join(', ')}</small>
                        <small>Đưa mã QR này cho nhân viên rạp để xác thực vé.</small>
                        <button type="button" className="btn btn-ghost btn-small" onClick={() => window.print()}>In vé / Lưu PDF</button>
                      </div>
                    </details>
                  )}
                  {canCancel && <button className="btn btn-danger btn-small" onClick={() => cancel(booking._id)}>Hủy vé</button>}
                </div>
              </article>
            );
          })}
        </div>
      ) : <div className="empty-state">Bạn chưa có vé nào.</div>}
    </div>
  );
}
