import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, getApiError } from '../services/api';
import SectionTitle from '../components/SectionTitle';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';

export default function AdminDashboardPage() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');
  const [qrToken, setQrToken] = useState('');
  const [verifyingQr, setVerifyingQr] = useState(false);
  const [verifiedTicket, setVerifiedTicket] = useState(null);

  useEffect(() => {
    api.get('/admin/stats')
      .then((response) => setStats(response.data.data))
      .catch((err) => setError(getApiError(err)));
  }, []);

  const verifyTicket = async (event) => {
    event.preventDefault();
    setVerifyingQr(true);
    setVerifiedTicket(null);
    setError('');
    try {
      const response = await api.post('/bookings/verify-qr', { qrToken: qrToken.trim() });
      setVerifiedTicket(response.data.data.ticket);
      setQrToken('');
    } catch (err) {
      setError(getApiError(err));
    } finally {
      setVerifyingQr(false);
    }
  };

  return (
    <div className="container section-block">
      <SectionTitle eyebrow="KHU VỰC QUẢN TRỊ" title="Dashboard" description="Quản lý phim, phòng chiếu, suất chiếu, voucher và theo dõi doanh thu." />
      <div className="admin-links">
        <Link to="/admin/movies">Quản lý phim →</Link>
        <Link to="/admin/rooms">Quản lý phòng →</Link>
        <Link to="/admin/showtimes">Quản lý suất chiếu →</Link>
        <Link to="/admin/vouchers">Quản lý voucher →</Link>
      </div>

      <section className="panel admin-qr-verify-panel">
        <h3>Xác thực vé bằng mã QR</h3>
        <p>Quét QR bằng thiết bị đọc mã, sau đó dán nội dung QR vào đây để kiểm tra và ghi nhận vé đã sử dụng.</p>
        <form onSubmit={verifyTicket} className="admin-qr-verify-form">
          <textarea value={qrToken} onChange={(event) => setQrToken(event.target.value)} placeholder="Dán nội dung mã QR của vé vào đây..." rows="3" required />
          <button className="btn btn-primary" disabled={verifyingQr || !qrToken.trim()}>{verifyingQr ? 'Đang xác thực...' : 'Xác thực vé'}</button>
        </form>
        {verifiedTicket && (
          <div className="admin-qr-verified-result">
            <b>Vé hợp lệ: {verifiedTicket.ticketCode}</b>
            <span>{verifiedTicket.movie} · {verifiedTicket.room}</span>
            <span>Ghế: {verifiedTicket.seats.join(', ')}</span>
            <small>Đã ghi nhận sử dụng lúc {new Date(verifiedTicket.checkedInAt).toLocaleString('vi-VN')}.</small>
          </div>
        )}
      </section>

      <ErrorMessage message={error} />
      {!stats ? <Loading /> : <>
        <div className="stat-grid">
          <div className="stat-card"><span>Vé xác nhận</span><strong>{stats.summary.totalTickets || 0}</strong></div>
          <div className="stat-card"><span>Doanh thu</span><strong>{(stats.summary.revenue || 0).toLocaleString('vi-VN')} đ</strong></div>
        </div>
        <SectionTitle title="Doanh thu theo phim" />
        <div className="table-wrap"><table><thead><tr><th>Phim</th><th>Số vé</th><th>Doanh thu</th></tr></thead><tbody>{stats.byMovie.map((item) => <tr key={item._id}><td>{item.title}</td><td>{item.tickets}</td><td>{item.revenue.toLocaleString('vi-VN')} đ</td></tr>)}</tbody></table></div>
        <SectionTitle title="Doanh thu theo ngày" />
        <div className="table-wrap"><table><thead><tr><th>Ngày</th><th>Số vé</th><th>Doanh thu</th></tr></thead><tbody>{stats.byDay.map((item) => <tr key={item._id}><td>{item._id}</td><td>{item.tickets}</td><td>{item.revenue.toLocaleString('vi-VN')} đ</td></tr>)}</tbody></table></div>
      </>}
    </div>
  );
}
