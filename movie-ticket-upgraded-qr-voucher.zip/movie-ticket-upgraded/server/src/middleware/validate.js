import { ApiError } from '../utils/ApiError.js';
export function requireFields(fields) {
  return (req, res, next) => {
    const missing = fields.filter((field) => req.body[field] === undefined || req.body[field] === null || req.body[field] === '');
    if (missing.length) return next(new ApiError(400, `Thiếu dữ liệu: ${missing.join(', ')}`));
    next();
  };
}
export function isValidEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '')); }
