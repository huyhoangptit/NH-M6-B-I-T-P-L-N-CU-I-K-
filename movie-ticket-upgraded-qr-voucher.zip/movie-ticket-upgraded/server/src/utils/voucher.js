import { ApiError } from './ApiError.js';

export function calculateDiscount(voucher, subtotal) {
  let discount = voucher.discountType === 'percent'
    ? Math.round(subtotal * voucher.discountValue / 100)
    : voucher.discountValue;
  if (voucher.maxDiscount && discount > voucher.maxDiscount) discount = voucher.maxDiscount;
  return Math.min(subtotal, Math.max(0, discount));
}

export function validateVoucherRules(voucher, subtotal, now = new Date()) {
  if (!voucher || !voucher.isActive) throw new ApiError(400, 'Mã voucher không tồn tại hoặc đã bị vô hiệu hóa.');
  if (voucher.startsAt && voucher.startsAt > now) throw new ApiError(400, 'Mã voucher chưa đến thời gian sử dụng.');
  if (voucher.expiresAt && voucher.expiresAt < now) throw new ApiError(400, 'Mã voucher đã hết hạn.');
  if (voucher.usageLimit !== null && voucher.usageLimit !== undefined && voucher.usedCount >= voucher.usageLimit) {
    throw new ApiError(400, 'Mã voucher đã hết lượt sử dụng.');
  }
  if (subtotal < voucher.minOrderValue) {
    throw new ApiError(400, `Đơn hàng cần đạt tối thiểu ${Number(voucher.minOrderValue).toLocaleString('vi-VN')} đ để sử dụng mã này.`);
  }
}
