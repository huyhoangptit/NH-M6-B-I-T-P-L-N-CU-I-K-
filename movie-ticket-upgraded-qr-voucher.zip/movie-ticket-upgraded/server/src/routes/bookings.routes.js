import { Router } from 'express';
import { randomBytes } from 'node:crypto';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import { Booking } from '../models/Booking.js';
import { Showtime } from '../models/Showtime.js';
import { Voucher } from '../models/Voucher.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { calculateDiscount, validateVoucherRules } from '../utils/voucher.js';

const router = Router();
router.use(requireAuth);

function createTicketQrToken(bookingId, ticketCode, showtimeEndAt) {
  const expiryTime = new Date(showtimeEndAt).getTime() + 24 * 60 * 60 * 1000;
  const expiresIn = Math.max(60, Math.floor((expiryTime - Date.now()) / 1000));
  return jwt.sign(
    { purpose: 'hth-cinema-ticket', bookingId: String(bookingId), ticketCode },
    process.env.JWT_SECRET,
    { expiresIn }
  );
}

async function releaseVoucherUsage(voucherId) {
  if (!voucherId) return;
  await Voucher.updateOne({ _id: voucherId, usedCount: { $gt: 0 } }, { $inc: { usedCount: -1 } });
}

router.post('/', asyncHandler(async (req, res) => {
  const { showtimeId, seats, customer, voucherCode: rawVoucherCode } = req.body;
  if (!customer || typeof customer.name !== 'string' || customer.name.trim().length < 2 || typeof customer.phone !== 'string' || !/^[0-9+ .()\-]{9,18}$/.test(customer.phone.trim()) || typeof customer.email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email.trim())) {
    throw new ApiError(400, 'Vui lòng nhập họ tên, số điện thoại và email hợp lệ của người đặt.');
  }
  if (!showtimeId || !Array.isArray(seats) || !seats.length) throw new ApiError(400, 'Vui lòng chọn suất chiếu và ít nhất một ghế.');
  if (seats.length > 8) throw new ApiError(400, 'Mỗi lần chỉ được đặt tối đa 8 ghế.');
  if (new Set(seats).size !== seats.length || seats.some((seat) => typeof seat !== 'string')) throw new ApiError(400, 'Danh sách ghế không hợp lệ.');

  const showtime = await Showtime.findById(showtimeId).populate('room').populate('movie');
  if (!showtime || !showtime.active) throw new ApiError(404, 'Không tìm thấy suất chiếu.');
  if (showtime.startAt <= new Date()) throw new ApiError(400, 'Suất chiếu đã bắt đầu hoặc đã qua.');

  const rowNames = Array.from({ length: showtime.room.rows }, (_, index) => String.fromCharCode(65 + index));
  const validSeats = new Set(rowNames.flatMap((row) => Array.from({ length: showtime.room.seatsPerRow }, (_, index) => `${row}${index + 1}`)));
  const invalidSeats = seats.filter((seat) => !validSeats.has(seat));
  if (invalidSeats.length) throw new ApiError(400, `Ghế không tồn tại: ${invalidSeats.join(', ')}`);

  const occupied = await Booking.distinct('seats.code', {
    showtime: showtime._id,
    status: 'confirmed',
    'seats.code': { $in: seats }
  });
  if (occupied.length) {
    res.status(409).json({ success: false, message: 'Một số ghế đã được người khác đặt.', conflictSeats: occupied });
    return;
  }

  const seatDetails = seats.map((code) => {
    const type = showtime.room.vipRows.includes(code[0]) ? 'vip' : 'normal';
    return { code, type, price: type === 'vip' ? showtime.priceVip : showtime.priceNormal };
  });
  const subtotal = seatDetails.reduce((sum, seat) => sum + seat.price, 0);

  let selectedVoucher = null;
  let discountAmount = 0;
  let reservedVoucherId = null;
  const voucherCode = String(rawVoucherCode || '').trim().toUpperCase();

  if (voucherCode) {
    selectedVoucher = await Voucher.findOne({ code: voucherCode });
    validateVoucherRules(selectedVoucher, subtotal);
    const reservedVoucher = await Voucher.findOneAndUpdate(
      {
        _id: selectedVoucher._id,
        isActive: true,
        startsAt: { $lte: new Date() },
        expiresAt: { $gte: new Date() },
        minOrderValue: { $lte: subtotal },
        $or: [
          { usageLimit: null },
          { $expr: { $lt: ['$usedCount', '$usageLimit'] } }
        ]
      },
      { $inc: { usedCount: 1 } },
      { new: true }
    );
    if (!reservedVoucher) throw new ApiError(400, 'Voucher vừa hết lượt sử dụng hoặc không còn hiệu lực. Vui lòng kiểm tra lại.');
    selectedVoucher = reservedVoucher;
    reservedVoucherId = reservedVoucher._id;
    discountAmount = calculateDiscount(reservedVoucher, subtotal);
  }

  const total = Math.max(0, subtotal - discountAmount);
  const ticketCode = `HTH-${randomBytes(5).toString('hex').toUpperCase()}`;
  const bookingId = new mongoose.Types.ObjectId();
  const qrToken = createTicketQrToken(bookingId, ticketCode, showtime.endAt);

  try {
    const booking = await Booking.create({
      _id: bookingId,
      user: req.user._id,
      showtime: showtime._id,
      customer: {
        name: customer.name.trim(),
        phone: customer.phone.trim(),
        email: customer.email.trim().toLowerCase()
      },
      seats: seatDetails,
      subtotal,
      discountAmount,
      voucher: selectedVoucher ? {
        voucherId: selectedVoucher._id,
        code: selectedVoucher.code,
        description: selectedVoucher.description
      } : undefined,
      total,
      status: 'confirmed',
      ticketCode,
      qrToken
    });
    res.status(201).json({
      success: true,
      message: 'Đặt vé thành công. Mã QR vé đã được tạo.',
      data: { booking }
    });
  } catch (error) {
    if (reservedVoucherId) await releaseVoucherUsage(reservedVoucherId);
    if (error.code === 11000) {
      const latest = await Booking.distinct('seats.code', {
        showtime: showtime._id,
        status: 'confirmed',
        'seats.code': { $in: seats }
      });
      res.status(409).json({ success: false, message: 'Ghế vừa được người khác đặt. Vui lòng chọn ghế khác.', conflictSeats: latest });
      return;
    }
    throw error;
  }
}));

router.get('/my', asyncHandler(async (req, res) => {
  const bookings = await Booking.find({ user: req.user._id })
    .populate({ path: 'showtime', populate: [{ path: 'movie', select: 'title posterUrl' }, { path: 'room', select: 'name' }] })
    .sort({ createdAt: -1 });

  // Vé được tạo trước khi có QR sẽ được cấp mã QR khi người dùng mở lịch sử vé.
  for (const booking of bookings) {
    const qrValidUntil = booking.showtime?.endAt
      ? new Date(booking.showtime.endAt).getTime() + 24 * 60 * 60 * 1000
      : 0;
    if (booking.status === 'confirmed' && !booking.qrToken && qrValidUntil > Date.now()) {
      booking.qrToken = createTicketQrToken(booking._id, booking.ticketCode, booking.showtime.endAt);
      await booking.save();
    }
  }
  res.json({ success: true, data: { bookings } });
}));

// Admin có thể dùng token trong QR để xác thực vé; token chỉ hợp lệ đến 24 giờ sau khi suất kết thúc.
router.post('/verify-qr', requireRole('admin'), asyncHandler(async (req, res) => {
  const qrToken = String(req.body.qrToken || '').trim();
  if (!qrToken) throw new ApiError(400, 'Vui lòng nhập dữ liệu QR của vé.');

  let payload;
  try {
    payload = jwt.verify(qrToken, process.env.JWT_SECRET);
  } catch {
    throw new ApiError(400, 'Mã QR không hợp lệ hoặc đã hết hạn.');
  }
  if (payload.purpose !== 'hth-cinema-ticket' || !mongoose.isValidObjectId(payload.bookingId)) {
    throw new ApiError(400, 'Mã QR không thuộc hệ thống HTH Cinema.');
  }

  const booking = await Booking.findById(payload.bookingId)
    .populate({ path: 'showtime', populate: [{ path: 'movie', select: 'title' }, { path: 'room', select: 'name' }] });
  if (!booking || booking.ticketCode !== payload.ticketCode) throw new ApiError(404, 'Không tìm thấy vé tương ứng với mã QR.');
  if (!booking.showtime) throw new ApiError(404, 'Suất chiếu gắn với vé này không còn tồn tại.');
  if (booking.status !== 'confirmed') throw new ApiError(400, 'Vé đã bị hủy, không thể sử dụng.');
  const entryOpensAt = booking.showtime.startAt.getTime() - 2 * 60 * 60 * 1000;
  if (Date.now() < entryOpensAt) throw new ApiError(400, 'Vé chỉ được xác thực trong vòng 2 tiếng trước giờ chiếu.');
  if (booking.checkedInAt) throw new ApiError(409, `Vé này đã được sử dụng lúc ${booking.checkedInAt.toLocaleString('vi-VN')}.`);

  // Atomic update để hai nhân viên quét cùng một QR đồng thời chỉ có một người thành công.
  const checkedInAt = new Date();
  const checkedInBooking = await Booking.findOneAndUpdate(
    { _id: booking._id, status: 'confirmed', checkedInAt: null },
    { $set: { checkedInAt, checkedInBy: req.user._id } },
    { new: true }
  );
  if (!checkedInBooking) {
    const latest = await Booking.findById(booking._id).select('checkedInAt status');
    if (latest?.checkedInAt) throw new ApiError(409, `Vé này vừa được sử dụng lúc ${latest.checkedInAt.toLocaleString('vi-VN')}.`);
    throw new ApiError(400, 'Vé không còn ở trạng thái có thể sử dụng.');
  }
  res.json({
    success: true,
    message: 'Xác thực QR thành công. Vé đã được ghi nhận sử dụng.',
    data: {
      ticket: {
        ticketCode: booking.ticketCode,
        movie: booking.showtime?.movie?.title,
        room: booking.showtime?.room?.name,
        seats: booking.seats.map((seat) => seat.code),
        checkedInAt: checkedInBooking.checkedInAt
      }
    }
  });
}));

router.patch('/:id/cancel', asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id).populate('showtime');
  if (!booking) throw new ApiError(404, 'Không tìm thấy vé.');
  const isOwner = booking.user.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== 'admin') throw new ApiError(403, 'Bạn không có quyền hủy vé này.');
  if (booking.status !== 'confirmed') throw new ApiError(400, 'Vé này đã được hủy.');
  if (booking.checkedInAt) throw new ApiError(400, 'Vé đã được sử dụng, không thể hủy.');
  const twoHours = 2 * 60 * 60 * 1000;
  if (booking.showtime.startAt.getTime() - Date.now() < twoHours) throw new ApiError(400, 'Chỉ được hủy vé trước giờ chiếu ít nhất 2 tiếng.');
  booking.status = 'cancelled';
  await booking.save();
  if (booking.voucher?.voucherId && !booking.voucherUsageReleased) {
    await releaseVoucherUsage(booking.voucher.voucherId);
    booking.voucherUsageReleased = true;
    await booking.save();
  }
  res.json({ success: true, data: { booking }, message: 'Đã hủy vé.' });
}));

export default router;
