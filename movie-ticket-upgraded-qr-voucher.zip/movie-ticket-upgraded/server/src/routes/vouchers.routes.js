import { Router } from 'express';
import mongoose from 'mongoose';
import { Voucher } from '../models/Voucher.js';
import { Showtime } from '../models/Showtime.js';
import { Booking } from '../models/Booking.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { calculateDiscount, validateVoucherRules } from '../utils/voucher.js';

const router = Router();

function normalizeCode(value) {
  return String(value || '').trim().toUpperCase();
}

async function calculateSubtotal(showtimeId, seatCodes) {
  if (!showtimeId || !mongoose.isValidObjectId(showtimeId)) throw new ApiError(400, 'Suất chiếu không hợp lệ.');
  if (!Array.isArray(seatCodes) || seatCodes.length < 1) throw new ApiError(400, 'Vui lòng chọn ít nhất một ghế.');
  if (seatCodes.length > 8) throw new ApiError(400, 'Mỗi lần chỉ được đặt tối đa 8 ghế.');
  if (new Set(seatCodes).size !== seatCodes.length || seatCodes.some((seat) => typeof seat !== 'string')) {
    throw new ApiError(400, 'Danh sách ghế không hợp lệ.');
  }

  const showtime = await Showtime.findById(showtimeId).populate('room').populate('movie');
  if (!showtime || !showtime.active) throw new ApiError(404, 'Không tìm thấy suất chiếu.');
  if (showtime.startAt <= new Date()) throw new ApiError(400, 'Suất chiếu đã bắt đầu hoặc đã qua.');

  const rowNames = Array.from({ length: showtime.room.rows }, (_, index) => String.fromCharCode(65 + index));
  const validSeats = new Set(rowNames.flatMap((row) => Array.from(
    { length: showtime.room.seatsPerRow }, (_, index) => `${row}${index + 1}`
  )));
  const invalidSeats = seatCodes.filter((seat) => !validSeats.has(seat));
  if (invalidSeats.length) throw new ApiError(400, `Ghế không tồn tại: ${invalidSeats.join(', ')}`);

  const occupied = await Booking.distinct('seats.code', {
    showtime: showtime._id,
    status: 'confirmed',
    'seats.code': { $in: seatCodes }
  });
  if (occupied.length) {
    const error = new ApiError(409, `Các ghế ${occupied.join(', ')} vừa được người khác đặt.`);
    error.details = { conflictSeats: occupied };
    throw error;
  }

  const seatDetails = seatCodes.map((code) => {
    const type = showtime.room.vipRows.includes(code[0]) ? 'vip' : 'normal';
    return { code, type, price: type === 'vip' ? showtime.priceVip : showtime.priceNormal };
  });
  return {
    showtime,
    seatDetails,
    subtotal: seatDetails.reduce((sum, seat) => sum + seat.price, 0)
  };
}

// Thành viên kiểm tra mã trước khi xác nhận đặt vé. Server tự tính tiền từ suất chiếu và ghế.
router.post('/validate', requireAuth, asyncHandler(async (req, res) => {
  const code = normalizeCode(req.body.code);
  if (!/^[A-Z0-9_-]{3,30}$/.test(code)) throw new ApiError(400, 'Vui lòng nhập mã voucher gồm 3–30 ký tự chữ, số, dấu gạch ngang hoặc gạch dưới.');
  const { subtotal } = await calculateSubtotal(req.body.showtimeId, req.body.seats);
  const voucher = await Voucher.findOne({ code });
  validateVoucherRules(voucher, subtotal);
  const discountAmount = calculateDiscount(voucher, subtotal);
  res.json({
    success: true,
    message: `Áp dụng mã ${voucher.code} thành công. Bạn được giảm ${discountAmount.toLocaleString('vi-VN')} đ.`,
    data: {
      voucher: {
        id: voucher._id,
        code: voucher.code,
        description: voucher.description,
        discountType: voucher.discountType,
        discountValue: voucher.discountValue,
        maxDiscount: voucher.maxDiscount
      },
      subtotal,
      discountAmount,
      total: subtotal - discountAmount
    }
  });
}));

// Các API còn lại dành riêng cho Admin.
router.get('/', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const vouchers = await Voucher.find().sort({ createdAt: -1 });
  res.json({ success: true, data: { vouchers } });
}));

router.post('/', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const payload = { ...req.body, code: normalizeCode(req.body.code) };
  if (!/^[A-Z0-9_-]{3,30}$/.test(payload.code)) throw new ApiError(400, 'Mã voucher phải gồm 3–30 ký tự chữ, số, dấu gạch ngang hoặc gạch dưới.');
  if (!['percent', 'fixed'].includes(payload.discountType)) throw new ApiError(400, 'Loại giảm giá không hợp lệ.');
  if (!Number.isFinite(Number(payload.discountValue)) || Number(payload.discountValue) <= 0) throw new ApiError(400, 'Giá trị giảm giá phải lớn hơn 0.');
  if (payload.discountType === 'percent' && Number(payload.discountValue) > 100) throw new ApiError(400, 'Phần trăm giảm giá không được vượt quá 100%.');
  if (!payload.expiresAt || new Date(payload.expiresAt) <= new Date(payload.startsAt || Date.now())) throw new ApiError(400, 'Ngày hết hạn phải sau ngày bắt đầu.');
  if (payload.usageLimit !== '' && payload.usageLimit !== null && payload.usageLimit !== undefined && (!Number.isInteger(Number(payload.usageLimit)) || Number(payload.usageLimit) < 1)) throw new ApiError(400, 'Số lượt sử dụng phải là số nguyên lớn hơn 0 hoặc để trống.');
  if (payload.maxDiscount !== '' && payload.maxDiscount !== null && payload.maxDiscount !== undefined && (!Number.isFinite(Number(payload.maxDiscount)) || Number(payload.maxDiscount) <= 0)) throw new ApiError(400, 'Mức giảm tối đa phải lớn hơn 0 hoặc để trống.');
  const voucher = await Voucher.create({
    ...payload,
    discountValue: Number(payload.discountValue),
    maxDiscount: payload.maxDiscount === '' || payload.maxDiscount === null ? null : Number(payload.maxDiscount),
    minOrderValue: Number(payload.minOrderValue || 0),
    usageLimit: payload.usageLimit === '' || payload.usageLimit === null ? null : Number(payload.usageLimit),
    usedCount: 0
  });
  res.status(201).json({ success: true, data: { voucher }, message: `Tạo voucher ${voucher.code} thành công.` });
}));

router.put('/:id', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) throw new ApiError(400, 'Mã voucher không hợp lệ.');
  const current = await Voucher.findById(req.params.id);
  if (!current) throw new ApiError(404, 'Không tìm thấy voucher.');
  const payload = { ...req.body };
  if (payload.code !== undefined) payload.code = normalizeCode(payload.code);
  if (payload.discountValue !== undefined) payload.discountValue = Number(payload.discountValue);
  if (payload.maxDiscount === '') payload.maxDiscount = null;
  else if (payload.maxDiscount !== undefined && payload.maxDiscount !== null) payload.maxDiscount = Number(payload.maxDiscount);
  if (payload.minOrderValue !== undefined) payload.minOrderValue = Number(payload.minOrderValue);
  if (payload.usageLimit === '') payload.usageLimit = null;
  else if (payload.usageLimit !== undefined && payload.usageLimit !== null) payload.usageLimit = Number(payload.usageLimit);

  const nextCode = payload.code ?? current.code;
  const nextType = payload.discountType ?? current.discountType;
  const nextValue = payload.discountValue ?? current.discountValue;
  const nextStartsAt = new Date(payload.startsAt ?? current.startsAt);
  const nextExpiresAt = new Date(payload.expiresAt ?? current.expiresAt);
  const nextUsageLimit = payload.usageLimit !== undefined ? payload.usageLimit : current.usageLimit;
  const nextMaxDiscount = payload.maxDiscount !== undefined ? payload.maxDiscount : current.maxDiscount;
  if (!/^[A-Z0-9_-]{3,30}$/.test(nextCode)) throw new ApiError(400, 'Mã voucher không hợp lệ.');
  if (!['percent', 'fixed'].includes(nextType)) throw new ApiError(400, 'Loại giảm giá không hợp lệ.');
  if (!Number.isFinite(nextValue) || nextValue <= 0 || (nextType === 'percent' && nextValue > 100)) throw new ApiError(400, 'Giá trị giảm giá không hợp lệ.');
  if (nextExpiresAt <= nextStartsAt) throw new ApiError(400, 'Ngày hết hạn phải sau ngày bắt đầu.');
  if (nextUsageLimit !== null && nextUsageLimit !== undefined && (!Number.isInteger(Number(nextUsageLimit)) || Number(nextUsageLimit) < 1)) throw new ApiError(400, 'Số lượt sử dụng phải là số nguyên lớn hơn 0 hoặc để trống.');
  if (nextMaxDiscount !== null && nextMaxDiscount !== undefined && (!Number.isFinite(Number(nextMaxDiscount)) || Number(nextMaxDiscount) <= 0)) throw new ApiError(400, 'Mức giảm tối đa phải lớn hơn 0 hoặc để trống.');

  const allowedFields = ['code', 'description', 'discountType', 'discountValue', 'maxDiscount', 'minOrderValue', 'startsAt', 'expiresAt', 'usageLimit', 'isActive'];
  for (const field of allowedFields) {
    if (Object.prototype.hasOwnProperty.call(payload, field)) current[field] = payload[field];
  }
  await current.save();
  res.json({ success: true, data: { voucher: current }, message: `Cập nhật voucher ${current.code} thành công.` });
}));

router.delete('/:id', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) throw new ApiError(400, 'Mã voucher không hợp lệ.');
  const voucher = await Voucher.findByIdAndDelete(req.params.id);
  if (!voucher) throw new ApiError(404, 'Không tìm thấy voucher.');
  res.json({ success: true, message: `Đã xóa voucher ${voucher.code}.` });
}));

export default router;
