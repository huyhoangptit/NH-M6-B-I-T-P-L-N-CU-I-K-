import mongoose from 'mongoose';

const voucherSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, uppercase: true, trim: true, minlength: 3, maxlength: 30 },
  description: { type: String, default: '', trim: true, maxlength: 250 },
  discountType: { type: String, enum: ['percent', 'fixed'], required: true },
  discountValue: { type: Number, required: true, min: 1 },
  maxDiscount: { type: Number, default: null, min: 1 },
  minOrderValue: { type: Number, default: 0, min: 0 },
  startsAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
  usageLimit: { type: Number, default: null, min: 1 },
  usedCount: { type: Number, default: 0, min: 0 },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

voucherSchema.pre('validate', function validateVoucher() {
  if (this.discountType === 'percent' && this.discountValue > 100) {
    this.invalidate('discountValue', 'Phần trăm giảm giá không được vượt quá 100%.');
  }
  if (this.expiresAt && this.startsAt && this.expiresAt <= this.startsAt) {
    this.invalidate('expiresAt', 'Ngày hết hạn phải sau ngày bắt đầu.');
  }
});

export const Voucher = mongoose.model('Voucher', voucherSchema);
