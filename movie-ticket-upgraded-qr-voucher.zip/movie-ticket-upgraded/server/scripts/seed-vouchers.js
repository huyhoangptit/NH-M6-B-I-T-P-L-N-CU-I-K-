import 'dotenv/config';
import mongoose from 'mongoose';
import { Voucher } from '../src/models/Voucher.js';

await mongoose.connect(process.env.MONGODB_URI);
await Voucher.init();

const now = new Date();
const expiresAt = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
const samples = [
  {
    code: 'HTH10',
    description: 'Giảm 10% cho đơn từ 100.000 đ, tối đa 50.000 đ.',
    discountType: 'percent',
    discountValue: 10,
    maxDiscount: 50000,
    minOrderValue: 100000,
    startsAt: new Date(now.getTime() - 60 * 1000),
    expiresAt,
    usageLimit: 200,
    isActive: true
  },
  {
    code: 'HTH50000',
    description: 'Giảm trực tiếp 50.000 đ cho đơn từ 250.000 đ.',
    discountType: 'fixed',
    discountValue: 50000,
    maxDiscount: null,
    minOrderValue: 250000,
    startsAt: new Date(now.getTime() - 60 * 1000),
    expiresAt,
    usageLimit: 100,
    isActive: true
  }
];

for (const sample of samples) {
  await Voucher.updateOne({ code: sample.code }, { $setOnInsert: sample }, { upsert: true });
}

console.log('Đã tạo (hoặc giữ nguyên nếu đã tồn tại) hai voucher mẫu: HTH10 và HTH50000.');
await mongoose.disconnect();
