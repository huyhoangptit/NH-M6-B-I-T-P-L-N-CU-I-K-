# CineTicket – Website đặt vé xem phim

Dự án được tổ chức theo kiến trúc **React (Vite) + React Router + Redux Toolkit + Node.js/Express + MongoDB**. Bản cập nhật này giữ lại phong cách giao diện HTH từ website gốc: header đen, logo đỏ, thanh tìm kiếm ở giữa, banner đỏ-đen và khung 4 poster. Các poster JPG gốc trong thư mục `images` của bạn đã được đưa vào `client/public/posters`; luồng API/đặt vé/Admin vẫn được giữ lại.

## 1. Yêu cầu cài đặt

- Node.js 18 trở lên, npm.
- MongoDB local hoặc MongoDB Atlas.
- VS Code (khuyến nghị).

## 2. Cài đặt

Mở terminal tại thư mục gốc dự án:

```bash
cd server
npm install
```

Tạo file `server/.env` từ `.env.example` nếu chưa có (PowerShell: `Copy-Item .env.example .env` khi đang đứng trong thư mục `server`), sau đó cập nhật `MONGODB_URI` và `JWT_SECRET`. Nếu bạn đã có `server/.env` từ lần chạy trước, không ghi đè file đó; chỉ bổ sung ba biến `VIETQR_*` và biến `PAYMENT_HOLD_MINUTES` ở mục 12. Tài khoản mẫu trong `.env.example` được lấy theo đoạn thông tin bạn gửi; hãy xác nhận tên/số tài khoản trong ứng dụng HDBank trước khi dùng.

Nếu đây là database mới, chạy seed lần đầu (lệnh này xóa dữ liệu cũ trong database `cineticket` trước khi tạo dữ liệu mẫu):

```bash
npm run seed
```

Sau khi seed dữ liệu phim và phòng, tạo hai voucher mẫu (lệnh này không xóa dữ liệu):

```bash
npm run seed:vouchers
```

Nếu bạn đã có database từ bản dự án trước, **không chạy lại `npm run seed`**. Có thể thêm voucher mẫu và lịch chiếu bằng hai lệnh không xóa dữ liệu `npm run seed:vouchers` và `npm run seed:showtimes`. Dùng lệnh sau để bổ sung giờ chiếu:

```bash
npm run seed:showtimes
```

Sau đó khởi động Backend:

```bash
npm run dev
```

Mở terminal thứ hai. Trong PowerShell, tạo file môi trường bằng lệnh `Copy-Item .env.example .env` khi đang đứng trong thư mục `client`, sau đó chạy:

```bash
cd client
npm install
npm run dev
```

Truy cập URL Vite in ra terminal (thường là `http://localhost:5173`). Backend chạy ở `http://localhost:5000`.

## 3. Tài khoản demo

Script seed tạo tài khoản quản trị và dữ liệu lịch chiếu mẫu (mỗi phim một phòng, 4 khung giờ/ngày trong 7 ngày):

- Email: `admin@cineticket.local`
- Mật khẩu: `Admin123!`

Voucher mẫu sau khi chạy `npm run seed:vouchers`: `HTH10` (giảm 10%, tối đa 50.000 đ, đơn từ 100.000 đ) và `HTH50000` (giảm 50.000 đ, đơn từ 250.000 đ).

Bạn nên đổi mật khẩu demo trước khi triển khai công khai. Người dùng thường có thể tự đăng ký tại trang Đăng ký.

## 4. Chức năng đã được xây dựng trong bản này

- Giao diện trang chủ giữ phong cách HTH: logo đỏ, header đen, ô tìm kiếm, banner đỏ-đen, 4 poster mỗi trang và phân trang.
- Danh sách phim, tìm kiếm từ header, lọc thể loại/trạng thái/ngày chiếu và phân trang ở server.
- Chi tiết phim, trailer YouTube, thời lượng, các suất chiếu.
- Đăng ký/đăng nhập JWT; mật khẩu mã hóa bcrypt; vai trò `user` và `admin`.
- Mã QR thanh toán VietQR cho mỗi đơn (số tiền sau voucher + nội dung chuyển khoản riêng); Admin đối soát và xác nhận tiền thủ công. Sau xác nhận mới phát hành mã QR vé riêng, token được ký bằng JWT; Admin xác thực QR vé và hệ thống đánh dấu vé đã sử dụng để tránh quét lại.
- Voucher giảm theo phần trăm hoặc số tiền cố định; có thời hạn, đơn tối thiểu, mức giảm tối đa và giới hạn lượt dùng. Máy chủ tính lại giá/giảm giá khi xác nhận đặt vé.
- React Router gồm route động, route lồng, Outlet, NavLink active, route bảo vệ và 404.
- Context API cho phiên đăng nhập; Redux Toolkit quản lý ghế được chọn.
- Sơ đồ ghế được sinh từ cấu hình phòng, hỗ trợ ghế thường/VIP/đã bán; giới hạn 8 ghế.
- Tổng tiền dùng `useMemo`; trang chọn ghế có bộ đếm 5 phút với cleanup.
- Server kiểm tra ghế trùng, trả HTTP 409 và tên ghế xung đột.
- Hủy vé chỉ được thực hiện khi còn ít nhất 2 giờ trước giờ chiếu.
- Admin thêm/sửa/xóa phim, phòng, suất chiếu; server chặn suất chiếu chồng giờ cùng phòng và bắt buộc mỗi phim chỉ được gán một phòng duy nhất.
- Trang giới thiệu phim có chọn ngày và nhiều khung giờ; dữ liệu seed tạo 4 suất/ngày trong 7 ngày cho mỗi phim, tất cả nằm trong cùng một phòng.
- Trang chọn ghế dùng viền trắng phát sáng nhịp nhàng cho ghế đang chọn.
- Trang xác nhận đặt vé có thông tin người đặt (họ tên, số điện thoại, email); thông tin được lưu cùng booking trong MongoDB.
- Thống kê doanh thu theo phim và theo ngày bằng MongoDB Aggregation Pipeline.
- 6 collection có quan hệ: users, movies, rooms, showtimes, bookings và vouchers.
- Middleware xác thực, phân quyền, kiểm tra dữ liệu và xử lý lỗi tập trung.

## 5. Cấu trúc

```text
movie-ticket-upgraded/
├── client/                 # React + Vite
│   ├── public/posters/     # Poster JPG lấy từ dự án gốc và ảnh dự phòng SVG
│   └── src/
│       ├── components/
│       ├── context/
│       ├── hooks/
│       ├── pages/
│       ├── services/
│       └── store/
└── server/                 # Express + Mongoose
    ├── src/
    │   ├── config/
    │   ├── middleware/
    │   ├── models/
    │   ├── routes/
    │   └── utils/
    └── scripts/seed.js
```

## 6. Một số lưu ý nghiệp vụ

1. Website tạo QR chuyển khoản VietQR với số tiền và nội dung đơn hàng. Khách chuyển khoản, bấm “Tôi đã chuyển khoản”; Admin phải đối soát giao dịch trong tài khoản ngân hàng rồi mới xác nhận và cấp QR vé. Website chưa tự động xác minh tiền vào qua webhook ngân hàng.
2. Hệ thống dùng unique multikey index theo `showtime + seats.code` cho các đơn đang giữ ghế, đã báo chuyển khoản và đã xác nhận. Trường hợp hai người đồng thời tạo đơn cho cùng ghế, database chỉ chấp nhận một thao tác; thao tác còn lại nhận mã 409.
3. Bộ đếm 5 phút hiện chạy ở giao diện chọn ghế theo yêu cầu đề. Đây không phải cơ chế khóa ghế tạm thời phía server; ghế chỉ chắc chắn được giữ khi API tạo booking thành công. Server luôn kiểm tra lại ghế ở thời điểm xác nhận.
4. Các API quản trị cần tài khoản admin. Không được coi việc ẩn nút trên giao diện là cơ chế phân quyền.
5. Dữ liệu mẫu tạo 28 suất chiếu cho mỗi phim trong 7 ngày (09:00, 13:00, 17:00, 21:00). Mỗi phim chỉ sử dụng một phòng cố định; backend từ chối nếu quản trị viên cố gán phim đó sang phòng khác. Nếu database đã được seed từ bản trước, chạy `npm run seed:showtimes` để bổ sung lịch chiếu mà không xóa tài khoản, phim, phòng hoặc vé hiện có. Script chỉ bỏ qua các khung giờ trùng với suất đã tồn tại.
6. Các poster gốc đã được chép vào `client/public/posters/` và `server/scripts/seed.js` đã trỏ tới các ảnh này. Nếu chỉnh sửa dữ liệu mẫu, cập nhật `posterUrl` tương ứng. Chạy lại `npm run seed` sẽ xóa dữ liệu hiện tại trong database `cineticket` trước khi tạo dữ liệu mẫu.

## 7. API chính

| Method | URL | Quyền | Mục đích |
|---|---|---|---|
| POST | `/api/auth/register` | Khách | Đăng ký |
| POST | `/api/auth/login` | Khách | Đăng nhập |
| GET | `/api/auth/me` | User/Admin | Thông tin hiện tại |
| GET | `/api/movies` | Công khai | Danh sách, tìm kiếm, lọc, phân trang |
| GET | `/api/movies/:id` | Công khai | Chi tiết phim |
| POST/PUT/DELETE | `/api/movies[/ :id]` | Admin | CRUD phim |
| GET | `/api/rooms` | Công khai | Danh sách phòng |
| POST/PUT/DELETE | `/api/rooms[/ :id]` | Admin | CRUD phòng |
| GET | `/api/showtimes` | Công khai | Danh sách suất chiếu |
| GET | `/api/showtimes/:id` | Công khai | Chi tiết suất chiếu và ghế đã bán |
| POST/PUT/DELETE | `/api/showtimes[/ :id]` | Admin | CRUD suất chiếu |
| POST | `/api/bookings` | User | Tạo đơn chờ thanh toán, áp dụng voucher và trả thông tin VietQR |
| GET | `/api/bookings/:id/payment` | Chủ đơn/Admin | Lấy QR thanh toán và trạng thái đơn |
| POST | `/api/bookings/:id/notify-payment` | Chủ đơn | Báo đã chuyển khoản |
| GET | `/api/bookings/admin/pending-payments` | Admin | Danh sách đơn chờ đối soát |
| PATCH | `/api/bookings/:id/confirm-payment` | Admin | Xác nhận đã nhận tiền và phát hành QR vé |
| PATCH | `/api/bookings/:id/reject-payment` | Admin | Từ chối giao dịch và giải phóng ghế |
| GET | `/api/bookings/my` | User | Lịch sử vé kèm QR token |
| POST | `/api/bookings/verify-qr` | Admin | Xác thực QR, ghi nhận vé đã sử dụng |
| POST | `/api/vouchers/validate` | User | Kiểm tra voucher và tính mức giảm từ ghế đã chọn |
| GET/POST | `/api/vouchers` | Admin | Danh sách và tạo voucher |
| PUT/DELETE | `/api/vouchers/:id` | Admin | Sửa và xóa voucher |
| PATCH | `/api/bookings/:id/cancel` | Chủ vé/Admin | Hủy vé đúng điều kiện |
| GET | `/api/admin/stats` | Admin | Thống kê doanh thu |

## 8. Giao diện được giữ lại từ dự án gốc

- Logo `HTH`, thanh tìm kiếm, đường viền đỏ dưới header và khu vực tài khoản được dựng lại theo ảnh giao diện bạn gửi.
- Banner giữ tiêu đề “Phim Chiếu Rạp Hot Nhất Tuần” và dòng ưu đãi.
- Danh sách phim giữ bố cục bốn poster trên một hàng ở màn hình lớn, thứ tự poster giống trang chủ HTML gốc.
- Poster JPG được lấy trực tiếp từ thư mục `images` của file RAR ban đầu.
- Các màn hình chi tiết, chọn ghế, thanh toán, lịch sử và quản trị vẫn dùng chung tông màu đen-đỏ để đồng bộ với trang chủ.

## 9. Trước khi nộp bài

- Chạy thử toàn bộ luồng trên máy của bạn, đặc biệt là hai trình duyệt cùng đặt một ghế.
- Kiểm tra các đường dẫn poster trong `server/scripts/seed.js` nếu bạn thay ảnh.
- Cập nhật mã nhóm, thành viên, phần trăm đóng góp và repository trong báo cáo.
- Không đưa `.env` hoặc mật khẩu thật lên GitHub.
- Bổ sung ảnh chụp màn hình máy tính/điện thoại, báo cáo PDF và video demo 5–10 phút theo yêu cầu giảng viên.

## 10. Bộ lọc quản trị, giờ kết thúc và thông báo HTTP

- Trang quản lý phim: tìm theo tên/thể loại, lọc trạng thái đang chiếu/sắp chiếu và lọc thể loại.
- Trang quản lý phòng: tìm theo tên phòng, kích thước/số ghế, hàng VIP; lọc theo sức chứa.
- Trang quản lý suất chiếu: tìm theo tên phim hoặc phòng, lọc phòng, khoảng ngày và khoảng giờ bắt đầu.
- Form quản lý suất chiếu có cả giờ bắt đầu và giờ kết thúc. Khi chọn phim và giờ bắt đầu, hệ thống gợi ý giờ kết thúc theo thời lượng phim + 15 phút; Admin có thể chỉnh lại. Backend kiểm tra giờ kết thúc phải sau giờ bắt đầu và dùng giờ kết thúc đó để chặn suất chiếu chồng lấn.
- Khung giờ đang được chọn ở trang chi tiết phim có nền đỏ, đồng bộ với giao diện HTH tham chiếu.
- Mỗi phản hồi HTTP từ Axios hiển thị toast ở góc trên bên phải: 200, 201, 400, 401, 403, 404, 500 (các mã khác như 409 cũng hiển thị mã thực tế). Lỗi mất kết nối được ghi là NET vì không có mã HTTP khi server không phản hồi.
- Bộ lọc được xử lý trên danh sách đã tải ở trình duyệt, không tạo request mới cho mỗi ký tự nhập. Toast HTTP chỉ xuất hiện khi có phản hồi thực sự từ server.

## Thông báo kết quả thao tác (HTTP Toast)

- Các thao tác ghi/sửa/xóa thành công (POST, PUT, PATCH, DELETE) hiển thị thông báo nền xanh ở góc trên bên phải.
- Các phản hồi lỗi HTTP hiển thị hộp nền đỏ, kèm mã HTTP, tên thao tác và thông điệp lỗi cụ thể do API trả về.
- Lỗi đặt vé trùng ghế hiển thị thêm mã ghế xung đột.
- Lỗi mất kết nối Backend hiển thị thông báo riêng.
- Các request GET tải dữ liệu thành công không bật thông báo để tránh nhiều toast khi người dùng mở trang; lỗi GET vẫn hiển thị thông báo đỏ.

## Quên mật khẩu bằng OTP email

Chức năng quên mật khẩu gửi mã OTP 6 chữ số đến **email đã đăng ký tài khoản**. Mã có hiệu lực 10 phút, tối đa 5 lần nhập sai; yêu cầu gửi lại được giới hạn tối thiểu 60 giây và có rate limit theo IP. Sau khi OTP hợp lệ, người dùng có 10 phút để đặt mật khẩu mới. Mật khẩu mới được mã hóa bằng bcrypt trước khi lưu.

### Cấu hình gửi email bằng Gmail

1. Dùng một tài khoản Gmail dành cho ứng dụng. Bật Xác minh 2 bước cho tài khoản Google.
2. Tạo **App Password** trong phần bảo mật tài khoản Google (không dùng mật khẩu Gmail thông thường).
3. Sao chép `server/.env.example` thành `server/.env` nếu chưa có.
4. Điền các biến SMTP trong `server/.env`:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=dia-chi-gmail-cua-ban@gmail.com
SMTP_PASS=mat-khau-ung-dung-16-ky-tu
SMTP_FROM=HTH Cinema <dia-chi-gmail-cua-ban@gmail.com>
```

5. Lưu `.env`, khởi động lại Backend bằng `npm run dev` trong thư mục `server`.
6. Đăng ký tài khoản bằng email bạn có thể truy cập, sau đó dùng email đó ở màn hình đăng nhập → **Quên mật khẩu?**.

Không đưa file `.env` hoặc App Password lên GitHub. Nếu chưa cấu hình SMTP, API sẽ trả lỗi dễ hiểu và không thể gửi email OTP.

### Luồng sử dụng

1. Nhập email tài khoản và chọn **Gửi mã OTP đến email**.
2. Nhập 6 chữ số nhận được trong email (có thể dán cả 6 số cùng lúc).
3. Khi OTP đúng, giao diện nhập mật khẩu mới sẽ xuất hiện.
4. Nhập mật khẩu mới và xác nhận lại. Mật khẩu phải có ít nhất 8 ký tự.
5. Quay lại đăng nhập bằng mật khẩu mới.


## 11. QR vé và voucher

- Sau khi Admin xác nhận đã nhận tiền, API mới cấp JWT riêng cho vé. QR vé trên trang Lịch sử vé chứa token này, không chứa họ tên, email hoặc số điện thoại người đặt. Token được ký bằng `JWT_SECRET`, chỉ có hiệu lực đến 24 giờ sau khi suất chiếu kết thúc. Trước đó khách chỉ có QR VietQR để chuyển khoản.
- Admin có thể dùng thiết bị quét QR đọc chuỗi token, dán vào mục **Xác thực vé bằng mã QR** trên Dashboard. Backend kiểm tra chữ ký, trạng thái vé, khung giờ và ngăn sử dụng lại cùng một vé. Việc xác thực chỉ mở trong vòng 2 tiếng trước giờ chiếu đến 24 giờ sau khi suất chiếu kết thúc.
- Người dùng nhập voucher ở trang xác nhận đặt vé. API `/api/vouchers/validate` tự tính giá dựa trên suất chiếu và ghế, không tin tổng tiền từ trình duyệt. Khi xác nhận đặt vé, server kiểm tra lại mã, giới hạn lượt dùng và tăng lượt dùng theo thao tác atomic.
- Khi vé được hủy đúng điều kiện, lượt sử dụng voucher được hoàn lại.
- Chạy `npm run seed:vouchers` để tạo hai mã mẫu `HTH10` và `HTH50000`; script dùng upsert, không xóa voucher hoặc dữ liệu hiện có.


## 12. Thanh toán chuyển khoản VietQR

Website dùng VietQR Quick Link để tạo ảnh QR chuyển khoản theo tài khoản ngân hàng nhận tiền. Tài liệu cú pháp Quick Link: https://www.vietqr.io/qr-dong. Có thể xem trước/tạo QR thủ công tại https://qr.sepay.vn/.

### Cấu hình tài khoản nhận tiền

Mở `server/.env` và thêm các biến sau (không bắt buộc cài API key cho Quick Link):

```env
VIETQR_BANK_ID=HDB
VIETQR_ACCOUNT_NO=0354880009
VIETQR_ACCOUNT_NAME=NGUYEN QUOC TUAN
PAYMENT_HOLD_MINUTES=15
```

Các thông tin ngân hàng trên lấy theo đoạn cấu hình bạn đã cung cấp. Chỉ giữ lại nếu đây là tài khoản bạn sở hữu hoặc được chủ tài khoản cho phép nhận tiền; nếu không, thay bằng tài khoản nhận tiền chính xác của rạp. `HDB` là mã HDBank, BIN 970437.

### Luồng thanh toán

1. Khách chọn ghế, điền thông tin và áp dụng voucher (nếu có).
2. Bấm **Tạo QR thanh toán**. Server tự tính số tiền sau voucher, tạo mã đơn và nội dung chuyển khoản dạng `HTH...` riêng cho đơn.
3. Server lưu đơn ở trạng thái `pending_payment`, giữ ghế trong 15 phút (hoặc đến trước giờ chiếu 1 phút nếu thời gian còn lại ngắn hơn), đồng thời trả URL ảnh VietQR.
4. Khách dùng ứng dụng ngân hàng quét QR, kiểm tra tên người nhận/số tiền/nội dung rồi chuyển khoản. Sau khi chuyển xong bấm **Tôi đã chuyển khoản**. Đơn chuyển sang `payment_reported`.
5. Admin mở Dashboard, đối chiếu giao dịch thực tế trong tài khoản ngân hàng theo số tiền và nội dung chuyển khoản. Chỉ khi thấy tiền vào đúng mới bấm **Đã nhận tiền**. Server chuyển đơn sang `confirmed` và tạo QR vé HTH. Nếu không nhận được tiền, Admin từ chối; ghế được giải phóng.
6. Đơn chưa báo chuyển khoản khi hết thời hạn sẽ tự chuyển `expired`, giải phóng ghế và hoàn lại lượt voucher đã giữ. Nếu khách đã bấm báo chuyển khoản, đơn tiếp tục được giữ trong danh sách chờ đối soát để tránh hủy nhầm một khoản tiền đang chuyển; Admin cần xác nhận hoặc từ chối sau khi kiểm tra ngân hàng.

**Quan trọng:** VietQR Quick Link chỉ tạo mã QR chứa thông tin chuyển khoản; ảnh QR không phải bằng chứng tiền đã vào tài khoản. Bản này xác nhận thủ công bởi Admin, chưa tích hợp webhook/API lịch sử giao dịch của HDBank hoặc trung gian thanh toán. Không được xác nhận đơn chỉ dựa trên ảnh chụp màn hình khách gửi.
